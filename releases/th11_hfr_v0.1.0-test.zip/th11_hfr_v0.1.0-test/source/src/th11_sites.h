/* TH11 v1.00a hooks. See TH11_DEVNOTES.md for calling conventions and audit. */
#include "th11_signatures.h"

static const uint8_t* site_expected(uintptr_t addr, size_t n) {
    for (size_t i = 0; i < sizeof th11_signatures / sizeof *th11_signatures; ++i)
        if (th11_signatures[i].addr == addr && th11_signatures[i].size >= n)
            return th11_signatures[i].bytes;
    LOG("INTERNAL ERROR: missing signature @%08x size=%u", (unsigned)addr, (unsigned)n);
    return NULL;
}
static void site_hook(uintptr_t addr, size_t n) { hook_site(addr, n, site_expected(addr, n)); }
static void site_call(uintptr_t addr, void* fn) { patch_call(addr, fn, site_expected(addr, 5)); }
static void emit_factor(void) { E(0xd8, 0x0d); E32((uint32_t)(uintptr_t)&g_factor); }

/* Gate a straight-line block; preserve the incoming flags on both branches.
   timer < 0 selects the global frame boundary, otherwise use the object's timer. */
static void gate_prefix(uintptr_t skip, int reg, int timer) {
    E(0x9c);
    if (timer < 0) E_not_major(); else E_timer_unchanged(reg, timer, timer + 4);
    E(0x75, 0x06, 0x9d); EJMP(skip);
    E(0x9d);
}
static void gate_block(uintptr_t addr, size_t n, uintptr_t skip, int reg, int timer) {
    STUB_BEGIN(); gate_prefix(skip, reg, timer); ECOPY(addr, n); EJMP(addr + n); site_hook(addr, n);
}
static void gate_callback(uintptr_t addr, size_t n) {
    STUB_BEGIN(); E(0x9c); E_timer_unchanged(R_ECX, 0x5c, 0x60);
    E(0x75, 0x04, 0x9d, 0x31, 0xc0, 0xc3); /* unchanged: restore flags, return 0 */
    E(0x9d); ECOPY(addr, n); EJMP(addr + n); site_hook(addr, n);
}
static void gate_shot_callback(uintptr_t addr) {
    STUB_BEGIN(); E(0x9c); E_timer_unchanged(R_EDX, 0, 4);
    E(0x75,0x04,0x9d,0x31,0xc0,0xc3);
    E(0x9d); ECOPY(addr,6); EJMP(addr+6); site_hook(addr,6);
}
static void install_speed_patches(void) {
    const uintptr_t perm[] = {0x41f963, 0x41fe23, 0x42956d, 0x4314b8, 0x459b0c};
    const uintptr_t temp[] = {0x402b7c, 0x44b4f3};
    const uintptr_t pset[] = {0x42c73f, 0x42c85d, 0x42d696, 0x42d7db};
    const uintptr_t prest[] = {0x42c8b6, 0x42d845, 0x42e6a5};
    for (size_t i=0; i<sizeof perm/sizeof *perm; ++i) patch_call_n(perm[i],stub_set_one_perm,6,site_expected(perm[i],6));
    for (size_t i=0; i<sizeof temp/sizeof *temp; ++i) patch_call_n(temp[i],stub_set_one_temp,6,site_expected(temp[i],6));
    for (size_t i=0; i<sizeof pset/sizeof *pset; ++i) patch_call_n(pset[i],stub_pause_set,6,site_expected(pset[i],6));
    for (size_t i=0; i<sizeof prest/sizeof *prest; ++i) patch_call_n(prest[i],stub_pause_restore,6,site_expected(prest[i],6));
    patch_call_n(0x4169d0,stub_set_ecl,6,site_expected(0x4169d0,6));
    /* Paired effective-speed restores and the laser manager's temporary zero stay intact. */
}

static void install_site_patches(void) {
    g_p = stub_begin();
    /* Bullet lifetime / collision grace counters; object Timer is +0x464. */
    gate_block(0x408cbc, 5, 0x408cd8, R_EBX, 0x464);

    /* Stage distortion consumes RNG and advances phase once per frame. */
    gate_block(0x402bc5, 10, 0x40311b, 0, -1);
    gate_block(0x403121, 6, 0x403127, 0, -1);

    /* State-5 items leave five values on the FPU stack. Retain the original pops
       and branch: on minor ticks synthesize SF=0 without decrementing. */
    STUB_BEGIN(); E_not_major(); E(0x75,0x07); E(0x39,0xff); EJMP(0x4235b6);
    ECOPY(0x4235af,7); EJMP(0x4235b6); site_hook(0x4235af,7);
    const uintptr_t item_accel[] = {0x4238f9, 0x4239a1};
    for (int i=0; i<2; ++i) {
        STUB_BEGIN(); E(0xdd,0x05); E32(0x498130); /* double 0.2 */
        E(0xd8,0x0d); E32(0x4a7948); E(0xde,0xc1);
        EJMP(item_accel[i]+6); site_hook(item_accel[i],6);
    }

    /* TH11 has line and beam lasers (no TH12 curved-laser class). */
    gate_block(0x425de0, 6, 0x425df1, R_EBP, 0x14);
    gate_block(0x426097, 9, 0x4260f6, R_EBP, 0x28);
    gate_block(0x427580, 9, 0x4275ec, R_ESI, 0x14);

    /* Player death drops must happen exactly once at timer=3. */
    gate_block(0x4312c6, 7, 0x4313e6, R_ESI, 0x944);
    gate_block(0x431ab6, 6, 0x431af7, R_ESI, 0x944);

    /* Reimu C speed bonus: frame-counted warmup and particle emission, but the
       doubled movement amount still applies on every sub-tick. */
    gate_block(0x43065f, 6, 0x430665, 0, -1);
    STUB_BEGIN(); E_not_major(); E(0x75,0x0d);
    E(0xd1,0x64,0x24,0x2c, 0xd1,0x64,0x24,0x10); /* shl movement x/y,1 */
    EJMP(0x4306ce);
    ECOPY(0x43066e,7); EJMP(0x430675); site_hook(0x43066e,7);
    /* Reimu B auto-collect, Yukari warp state, option loss timer. */
    gate_block(0x43078f, 6, 0x4307ab, 0, -1);
    STUB_BEGIN(); E(0x9c); E_not_major(); E(0x75,0x02,0x9d,0xc3);
    E(0x9d); ECOPY(0x430e50,9); EJMP(0x430e59); site_hook(0x430e50,9);
    gate_block(0x430b48, 6, 0x430b4e, 0, -1);
    /* Options include per-call easing and shot-specific callbacks. Keep their
       update at 60 Hz; the player itself and its shots remain sub-stepped. */
    gate_block(0x430b4e, 6, 0x430d91, 0, -1);

    /* Fixed-point movement is in 1/128 px units. Carry sub-tick truncation. */
    const uintptr_t ftol_sites[] = {0x430722,0x430735};
    for (int i=0; i<2; ++i) {
        uint8_t* st=g_p;
        /* At stock speed retain the game's original truncation, including ECL
           slow motion. Residuals only compensate the additional sub-division. */
        E(0x81,0x3d); E32((uint32_t)(uintptr_t)&g_factor); E32(0x3f800000);
        E(0x75,0x05); EJMP(0x4864e0);
        E(0xd8,0x05); E32((uint32_t)(uintptr_t)&g_move_residual[i]); E(0xd9,0xc0);
        ECALL(0x4864e0); E(0x50,0xdb,0x04,0x24,0x58,0xde,0xe9);
        E(0xd9,0x1d); E32((uint32_t)(uintptr_t)&g_move_residual[i]); E(0xc3);
        site_call(ftol_sites[i],st);
    }

    /* Shared MotionState Cartesian integration (also used by player shots). */
    STUB_BEGIN();
    E(0xd9,0x43,0x0c); emit_factor(); E(0xd8,0x03,0xd9,0x1b);
    E(0xd9,0x43,0x10); emit_factor(); E(0xd8,0x43,0x04,0xd9,0x5b,0x04);
    E(0xd9,0x43,0x14); emit_factor(); E(0xd8,0x43,0x08,0xd9,0x5b,0x08);
    E(0x8b,0xf3); EJMP(0x4595b7); site_hook(0x45959c,27);

    /* Player damage-source acceleration and displacement. */
    STUB_BEGIN(); E(0xd9,0x47,0x18); emit_factor(); E(0x51,0xd8,0x47,0x14);
    EJMP(0x4315ac); site_hook(0x4315a5,7);
    STUB_BEGIN(); E(0xd9,0x47,0xe0); emit_factor(); E(0x8b,0x44,0x24,0x10,0xd8,0x00,0xd9,0x18);
    E(0xd9,0x47,0xe8); emit_factor(); E(0xd8,0x47,0xe4,0xd9,0x5f,0xe4);
    EJMP(0x4315e4); site_hook(0x4315d0,20);
    STUB_BEGIN(); E(0xd9,0x46,0x18); emit_factor(); E(0x51,0xd8,0x46,0x14);
    EJMP(0x434569); site_hook(0x434562,7);
    const uintptr_t turn_sites[]={0x4315af,0x43456c};
    for (int i=0;i<2;++i) {
        STUB_BEGIN(); ECOPY(turn_sites[i],3); emit_factor();
        ECOPY(turn_sites[i]+3,3); EJMP(turn_sites[i]+6); site_hook(turn_sites[i],6);
    }

    /* Shot-cycle subtraction and ANM wait offsets are constants, not rates. */
    uint8_t* add_constant=g_p;
    E(0x8b,0x46,0x04,0x89,0x06,0xd9,0x44,0x24,0x04,0xd8,0x0d); E32((uint32_t)(uintptr_t)&g_logical);
    E(0xd8,0x46,0x08,0xd9,0x56,0x08); ECALL(0x4864e0);
    E(0x89,0x46,0x04,0xc2,0x04,0x00);
    site_call(0x4343fc,add_constant); site_call(0x4355cd,add_constant);

    /* Enemy damage still evaluated at 60 Hz, but its player-timer guard must
       see that the last sub-tick advanced the float timer. */
    STUB_BEGIN(); E(0x50,0xa1); E32((uint32_t)(uintptr_t)&g_ptf_prev);
    E(0x3b,0x05); E32((uint32_t)(uintptr_t)&g_ptf_cur); E(0x58);
    EJCC(0x85,0x434827); EJMP(0x43481c); site_hook(0x434814,6);

    /* Mesh distortion/UV callbacks consume random numbers or advance per call. */
    gate_callback(0x408070,7); gate_callback(0x452420,9);
    /* Shot callback table at 0x4a3a3c: homing turn/acceleration and gravity
       advance per call. Keep those decisions on each shot's integer timer;
       its position still integrates every sub-tick. The third callback
       (0x435330) just anchors a laser to its option and remains unguarded. */
    gate_shot_callback(0x434e30); gate_shot_callback(0x4352a0);
    stub_end();
    LOG("TH11 site patches installed (%u bytes of stubs)",(unsigned)g_stub_used);
}
