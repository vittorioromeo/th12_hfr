"""Verify a local TH11 executable against the frozen, reviewed hook signatures.
No game executable is distributed, modified, or uploaded. Python standard library only.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path


def verify(path):
    data = Path(path).read_bytes()
    if data[:2] != b'MZ':
        raise ValueError('Not a PE executable')
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    if data[pe:pe+4] != b'PE\0\0':
        raise ValueError('Invalid PE signature')
    machine, count = struct.unpack_from('<HH', data, pe+4)
    optsize = struct.unpack_from('<H', data, pe+20)[0]
    optional = pe+24
    magic = struct.unpack_from('<H', data, optional)[0]
    base = struct.unpack_from('<I', data, optional+28)[0]
    if (machine, magic, base) != (0x14c, 0x10b, 0x400000):
        raise ValueError('Requires x86 PE32 at image base 0x400000')
    sections=[]
    for i in range(count):
        _, va, size, raw = struct.unpack_from('<IIII', data, optional+optsize+i*40+8)
        sections.append((va, size, raw))
    signatures=json.loads(Path(__file__).with_name('th11_signatures.json').read_text())
    failures=[]
    for signature in signatures:
        address=int(signature['address'], 16)
        expected=bytes.fromhex(signature['bytes'])
        rva=address-base
        actual=None
        for va,size,raw in sections:
            if va <= rva and rva+len(expected) <= va+size:
                actual=data[raw+rva-va:raw+rva-va+len(expected)]
        if actual != expected:
            failures.append(signature['address'])
    if failures:
        raise ValueError('Unsupported/modified patch sites: '+', '.join(failures))
    return len(signatures), hashlib.sha256(data).hexdigest()


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executables', nargs='+')
    args=parser.parse_args()
    failed=False
    for path in args.executables:
        try:
            count, digest=verify(path)
            print(f'PASS {path}: {count} signatures; SHA256 {digest}')
        except (OSError, ValueError, struct.error) as exc:
            print(f'FAIL {path}: {exc}')
            failed=True
    raise SystemExit(int(failed))
