param([string]$Compiler='C:\msys64\mingw32\bin\gcc.exe')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
    & './build.ps1' -Game th11 -Compiler $Compiler
    $version='0.1.0-test'
    $root="build/package-th11-$([Guid]::NewGuid().ToString('N'))"
    $pkg="$root/th11_hfr_v$version"
    New-Item -ItemType Directory -Force "$pkg/source/src","$pkg/source/tools",'releases' | Out-Null
    Copy-Item 'build/th11/*' "$pkg/"
    Copy-Item 'TH11_README.md' "$pkg/README.md"
    Copy-Item 'TH11_DEVNOTES.md' "$pkg/"
    Copy-Item 'src/hfr11.c','src/launcher11.c','src/th11_sites.h','src/th11_install.h','src/th11_signatures.h' "$pkg/source/src/"
    Copy-Item 'tools/verify_th11.py','tools/th11_signatures.json','tools/test_th11.c','tools/test_th11_stubs.py' "$pkg/source/tools/"
    Copy-Item 'build.ps1','test_th11.ps1','package_th11.ps1','TH11_README.md','TH11_DEVNOTES.md','th11_hfr.ini' "$pkg/source/"
    $files=Get-ChildItem -LiteralPath $pkg -File
    $hashes=$files | ForEach-Object {"$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLower())  $($_.Name)"}
    Set-Content -LiteralPath "$pkg/SHA256SUMS.txt" -Value $hashes -Encoding ascii
    $zip="releases/th11_hfr_v$version.zip"
    if(Test-Path -LiteralPath $zip) {
        $backup="build/previous-th11-package-$([Guid]::NewGuid().ToString('N')).zip"
        Move-Item -LiteralPath $zip -Destination $backup
    }
    Compress-Archive -LiteralPath $pkg -DestinationPath $zip
    Write-Output (Resolve-Path -LiteralPath $zip).Path
} finally {Pop-Location}
