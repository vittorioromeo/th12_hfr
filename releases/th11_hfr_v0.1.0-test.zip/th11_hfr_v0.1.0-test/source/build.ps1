param([ValidateSet('th11','th12','all')][string]$Game='all', [string]$Compiler='C:\msys64\mingw32\bin\gcc.exe')
$ErrorActionPreference='Stop'
$compilerPath=(Get-Command $Compiler -ErrorAction Stop).Source
$savedPath=$env:PATH
$env:PATH="$(Split-Path -Parent $compilerPath);$savedPath"
Push-Location $PSScriptRoot
try {
    New-Item -ItemType Directory -Force build | Out-Null
    $targets=if ($Game -eq 'all') {@('th11','th12')} else {@($Game)}
    foreach ($target in $targets) {
        $suffix=if ($target -eq 'th11') {'11'} else {''}
        & $Compiler -std=gnu11 -O2 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -shared -static-libgcc "src/hfr$suffix.c" -o "build/${target}_hfr.dll" -ld3d9 -lwinmm '-Wl,--kill-at'
        if ($LASTEXITCODE) { throw "$target DLL build failed" }
        & $Compiler -std=gnu11 -O2 -s -mwindows -static-libgcc "src/launcher$suffix.c" -o "build/${target}_hfr.exe"
        if ($LASTEXITCODE) { throw "$target launcher build failed" }
        New-Item -ItemType Directory -Force "build/$target" | Out-Null
        Copy-Item "build/${target}_hfr.dll" "build/$target/dinput8.dll"
        Copy-Item "build/${target}_hfr.dll","build/${target}_hfr.exe","${target}_hfr.ini" "build/$target/"
    }
} finally { Pop-Location; $env:PATH=$savedPath }
