/*
 * th11_hfr.dll — high refresh rate patch for Touhou 11 ~ Subterranean Animism v1.00a
 * (th11.exe and th11e.exe share the same code layout).
 *
 * Design:
 *   The engine has a global "game speed" float (0x4a7948) that every Timer and most integrators
 *   already multiply by (ZUN uses it for the boss-death slow motion, ECL ins_447).  We run the
 *   engine's update pass at the display refresh rate; each UpdateFunc is classified either as
 *   SUB   (runs every sub-tick with game speed = logical * dt, dt = 60/refresh) or
 *   FRAME (runs only on the sub-tick where the integer frame counter increments, with the stock
 *          game speed, i.e. bit-identical 60 Hz behaviour).
 *   Draw funcs run every sub-tick, Present happens every sub-tick.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d9.h>
#include <mmsystem.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

/* ------------------------------------------------------------------ logging */
static FILE* g_log;
static void logf_(const char* fmt, ...) {
    if (!g_log) return;
    va_list ap; va_start(ap, fmt); vfprintf(g_log, fmt, ap); va_end(ap);
    fputc('\n', g_log); fflush(g_log);
}
#define LOG(...) logf_(__VA_ARGS__)

/* ------------------------------------------------------------------ config */
static struct {
    int fps;            /* 0 = auto from display */
    int vsync;          /* present interval one */
    int substep;        /* 1 = sub-step gameplay, 0 = stock logic at 60 Hz + high rate presentation */
    int log;
    int fullscreen_refresh; /* refresh rate to request in fullscreen (0 = auto = same as fps) */
    int show_stats;
    int enemy_interp;
    int debug;
    int subtick_input;      /* poll the keyboard/joystick every tick and feed movement/focus to the player */
    int d3d9ex;             /* create the device through Direct3D9Ex */
    int max_frame_latency;  /* IDirect3DDevice9Ex::SetMaximumFrameLatency (0 = leave default) */
    int flipex;             /* windowed: D3DSWAPEFFECT_FLIPEX (experimental) */
} cfg = { 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0 };

/* ------------------------------------------------------------------ patch utils */
static int patch_bytes(uintptr_t addr, const void* data, size_t n, const void* expect) {
    DWORD old;
    if (expect && memcmp((void*)addr, expect, n) != 0) {
        LOG("patch @%08x: unexpected original bytes, skipping", (unsigned)addr);
        return 0;
    }
    if (!VirtualProtect((void*)addr, n, PAGE_EXECUTE_READWRITE, &old)) return 0;
    memcpy((void*)addr, data, n);
    VirtualProtect((void*)addr, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), (void*)addr, n);
    return 1;
}
static int patch_call(uintptr_t addr, void* target, const void* expect5) {
    uint8_t b[5]; b[0] = 0xE8; int32_t rel = (int32_t)((uintptr_t)target - (addr + 5)); memcpy(b + 1, &rel, 4);
    return patch_bytes(addr, b, 5, expect5);
}
static int patch_jmp(uintptr_t addr, void* target, const void* expect5) {
    uint8_t b[5]; b[0] = 0xE9; int32_t rel = (int32_t)((uintptr_t)target - (addr + 5)); memcpy(b + 1, &rel, 4);
    return patch_bytes(addr, b, 5, expect5);
}
/* replace an n-byte instruction sequence (n>=5) with call target + nops */
static int patch_call_n(uintptr_t addr, void* target, size_t n, const void* expect) {
    uint8_t b[16]; memset(b, 0x90, sizeof b);
    b[0] = 0xE8; int32_t rel = (int32_t)((uintptr_t)target - (addr + 5)); memcpy(b + 1, &rel, 4);
    return patch_bytes(addr, b, n, expect);
}

/* ------------------------------------------------------------------ game symbols */
#define G_GAME_SPEED      (*(volatile float*)0x4a7948)
#define G_UPDATE_RUNNER   (*(uint8_t**)0x4c3234)
#define G_D3D_DEVICE      (*(IDirect3DDevice9**)0x4c3288)
#define G_PP              ((D3DPRESENT_PARAMETERS*)0x4c3374)
#define G_WINDOW_FLAGS    (*(uint32_t*)0x4c3dc0)
#define G_FRAME_TIME_DBL  (*(double*)0x4c3c38)
#define G_MISC_FLAGS      (*(uint32_t*)0x4c3810)
#define G_INPUT_CUR       (*(uint32_t*)0x4c92a8)
#define G_INPUT_PRESSED   (*(uint32_t*)0x4c92b4)
#define G_REPLAY_MANAGER  (*(uint8_t**)0x4a8eb8)   /* +0x10: mode; +0x1cc: frame (-1 = none); +0x1d4: stage */

typedef int (__stdcall *FrameFn)(void* ctx);
static FrameFn orig_frame_vsync = (FrameFn)0x446650;

/* ------------------------------------------------------------------ tick state */
static int    g_refresh = 60;      /* presents per second (display) */
static int    g_logic_rate = 60;   /* logic ticks per second (== g_refresh normally; a replay's recording rate during playback) */
static int g_replay_rate, g_replay_playing;
static int    g_skip_update = 0;   /* present without running the update list (duplicate frame) */
static unsigned g_lacc = 0;        /* Bresenham remainder: logic ticks per present */
static float  g_dt = 1.0f;         /* game frames per tick for SUB nodes */
static unsigned g_tick = 0;        /* sub-tick counter */
static float g_ptf_prev, g_ptf_cur;   /* player state timer (float) before/after the last Player node call */
static float g_move_residual[2];
static double g_t0 = 0;            /* wall-clock origin of the tick schedule */
static unsigned g_stat_skipped;
static unsigned g_last_units = 0;  /* units of the previous tick */
static unsigned g_prev_frame = 0;  /* frame index (within the 60-frame cycle) of the previous tick */
static int    g_major = 1;         /* this tick is a frame boundary */
static double g_phase = 0;         /* position of this tick inside the current frame, [0,1) */
static float  g_logical = 1.0f;    /* the game's own notion of game speed (1.0, or ECL slow-mo) */
static float  g_factor = 1.0f;     /* factor of the node currently running (1 or dt) */
static float  g_pause_shadow = 1.0f;

/* Sub-step lengths are chosen as multiples of 1/256 frame (dyadic, exact in float32), distributed with a
   Bresenham sequence so that exactly 60 frames elapse every R ticks. The engine's timers accumulate the
   sub-step in float and compare with integer frame counts; with dyadic steps every partial sum is exact,
   so timer events happen on the right tick with no drift (a constant 60/R would not be representable). */
#define UNITS_PER_FRAME 256
static unsigned g_units_acc;   /* Bresenham remainder */
static unsigned g_units_total; /* units elapsed at the start of the current tick (mod 60 frames) */
static void set_logic_rate(int rate) {
    if (!cfg.substep) rate = 60;
    if (rate < 60) rate = 60;
    if (rate > 1000) rate = 1000;
    g_logic_rate = rate;
    memset(g_move_residual, 0, sizeof g_move_residual);
    g_dt = cfg.substep ? 60.0f / (float)rate : 1.0f;
    g_tick = 0; g_units_acc = 0; g_units_total = 0; g_major = 1; g_phase = 0; g_lacc = 0; g_prev_frame = 0;
    g_t0 = 0;
    LOG("logic rate: %d ticks/s (nominal dt=%.6f frames/tick), present rate %d Hz, substep=%d", g_logic_rate, g_dt, g_refresh, cfg.substep);
}
static void recompute_rate(int refresh) {
    if (refresh < 60) refresh = 60;
    if (refresh > 1000) refresh = 1000;
    g_refresh = refresh;
    int want = cfg.substep ? (g_replay_playing ? (g_replay_rate ? g_replay_rate : 60) : refresh) : 60;
    if (want != g_logic_rate || g_tick == 0) set_logic_rate(want);
    else g_lacc = 0;
}
/* number of logic ticks to run for the next present slot */
static int ticks_for_slot(void) {
    g_lacc += (unsigned)g_logic_rate;
    int n = (int)(g_lacc / (unsigned)g_refresh);
    g_lacc -= (unsigned)n * (unsigned)g_refresh;
    return n;
}
static void advance_tick(void) {
    if (!cfg.substep || g_logic_rate == 60) { g_major = 1; g_dt = 1.0f; g_phase = 0; g_tick++; return; }
    /* this tick starts at g_units_total; it is a frame boundary tick if the previous tick started in an earlier frame */
    unsigned cur_frame = g_units_total / UNITS_PER_FRAME;
    g_major = (g_tick == 0) || (cur_frame != g_prev_frame);
    g_prev_frame = cur_frame;
    g_phase = (double)(g_units_total % UNITS_PER_FRAME) / UNITS_PER_FRAME;
    /* Bresenham step for this tick */
    g_units_acc += 60u * UNITS_PER_FRAME;
    unsigned u = g_units_acc / (unsigned)g_logic_rate;
    g_units_acc -= u * (unsigned)g_logic_rate;
    g_dt = (float)u / (float)UNITS_PER_FRAME;
    g_last_units = u;
    g_units_total += u;
    if (g_units_total >= 60u * UNITS_PER_FRAME) g_units_total -= 60u * UNITS_PER_FRAME; /* every R ticks (1 s) exactly */
    g_tick++;
}
/* Restart the sub-step sequence so that the current (frame boundary) tick is the first tick of the canonical
   sequence for this rate. Used at the first frame of every stage: the sub-step pattern within a frame then only
   depends on the frame number, which makes a recording and its playback run the same sequence of steps
   (at non-integer ratios such as 144/60 the pattern otherwise depends on when the game was started). */
static void schedule_reset_here(void) {
    memset(g_move_residual, 0, sizeof g_move_residual);
    g_ptf_prev = g_ptf_cur = 0;
    if (!cfg.substep || g_logic_rate == 60) return;
    g_units_acc = 60u * UNITS_PER_FRAME;
    unsigned u = g_units_acc / (unsigned)g_logic_rate;
    g_units_acc -= u * (unsigned)g_logic_rate;
    g_units_total = u; g_last_units = u; g_prev_frame = 0; g_phase = 0;
    g_dt = (float)u / (float)UNITS_PER_FRAME;
}

/* ------------------------------------------------------------------ node classification */
enum { MODE_FRAME = 0, MODE_SUB = 1 };
struct node_class { uint32_t func; int mode; const char* name; };
static struct node_class g_classes[] = {
    /* func (UpdateFunc callback address) , mode , name */
    { 0x408ec0, MODE_SUB,   "BulletManager"   },
    { 0x431c50, MODE_SUB,   "Player"          },
    { 0x4064d0, MODE_FRAME, "Bomb"            },
    { 0x424090, MODE_SUB,   "ItemManager"     },
    { 0x424d70, MODE_SUB,   "LaserManager"    },
    { 0x41cfb0, MODE_FRAME, "Gui"             },
    { 0x403900, MODE_SUB,   "Stage"           },
    { 0x455120, MODE_SUB,   "AnmManagerWorld" },
    { 0x455130, MODE_SUB,   "AnmManagerUI"    },
    { 0x40e300, MODE_FRAME, "Spellcard"       },
    { 0x4111a0, MODE_FRAME, "EnemyManager"    },
    { 0x421b20, MODE_FRAME, "PlayerBomb?"     },
    { 0x420840, MODE_FRAME, "GameManager"     },
};
static int g_sub_enabled[sizeof g_classes / sizeof g_classes[0]];

static int node_mode(uint32_t func) {
    if (!cfg.substep) return MODE_FRAME;
    for (size_t i = 0; i < sizeof g_classes / sizeof g_classes[0]; i++)
        if (g_classes[i].func == func) return g_sub_enabled[i] ? g_classes[i].mode : MODE_FRAME;
    return MODE_FRAME;
}

/* ------------------------------------------------------------------ game speed handling */
static inline void set_factor(float f) {
    g_factor = f;
    G_GAME_SPEED = g_logical * f;
}

/* stubs for the game's writes to the speed global */
float g_fpu_tmp __attribute__((used));
/* sites that store the literal 1.0 permanently (new logical speed 1.0) */
void __cdecl __attribute__((used)) speed_set_one_perm(void) { g_logical = 1.0f; G_GAME_SPEED = g_factor; }
/* sites that store 1.0 temporarily (restored later from a saved effective value) */
void __cdecl __attribute__((used)) speed_set_one_temp(void) { G_GAME_SPEED = g_factor; }
/* ECL ins_447: value on the FPU stack */
void __cdecl __attribute__((used)) speed_set_ecl_c(void) { g_logical = g_fpu_tmp; G_GAME_SPEED = g_logical * g_factor; }
/* pause: save + set 1.0 */
void __cdecl __attribute__((used)) speed_pause_set_c(void) { g_pause_shadow = g_logical; g_logical = 1.0f; G_GAME_SPEED = g_factor; }
/* pause: restore */
void __cdecl __attribute__((used)) speed_pause_restore_c(void) { g_logical = g_pause_shadow; G_GAME_SPEED = g_logical * g_factor; }

/* naked asm trampolines: the patched instruction is "fstp dword [0x4a7948]" (6 bytes) -> call stub (5) + nop */
__asm__(
    ".intel_syntax noprefix\n"
    ".globl _stub_set_one_perm\n_stub_set_one_perm:\n"
    "  fstp dword ptr [_g_fpu_tmp]\n  pushad\n  call _speed_set_one_perm\n  popad\n  ret\n"
    ".globl _stub_set_one_temp\n_stub_set_one_temp:\n"
    "  fstp dword ptr [_g_fpu_tmp]\n  pushad\n  call _speed_set_one_temp\n  popad\n  ret\n"
    ".globl _stub_set_ecl\n_stub_set_ecl:\n"
    "  fstp dword ptr [_g_fpu_tmp]\n  pushad\n  call _speed_set_ecl_c\n  popad\n  ret\n"
    ".globl _stub_pause_set\n_stub_pause_set:\n"
    "  fstp dword ptr [_g_fpu_tmp]\n  pushad\n  call _speed_pause_set_c\n  popad\n  ret\n"
    ".globl _stub_pause_restore\n_stub_pause_restore:\n"
    "  fstp dword ptr [_g_fpu_tmp]\n  pushad\n  call _speed_pause_restore_c\n  popad\n  ret\n"
    ".att_syntax\n"
);
extern void stub_set_one_perm(void), stub_set_one_temp(void), stub_set_ecl(void), stub_pause_set(void), stub_pause_restore(void);

/* ------------------------------------------------------------------ mini assembler for guard stubs */
static uint8_t* g_stub_mem; static size_t g_stub_used;
static uint8_t* stub_begin(void) {
    if (!g_stub_mem) g_stub_mem = (uint8_t*)VirtualAlloc(NULL, 0x10000, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    return g_stub_mem + g_stub_used;
}
static uint8_t* g_p;
#define E(...) do { const uint8_t b_[] = { __VA_ARGS__ }; memcpy(g_p, b_, sizeof b_); g_p += sizeof b_; } while (0)
static void E32(uint32_t v) { memcpy(g_p, &v, 4); g_p += 4; }
static void EJMP(uintptr_t target) { *g_p++ = 0xE9; E32((uint32_t)(target - ((uintptr_t)g_p + 4))); }
static void EJCC(uint8_t cc, uintptr_t target) { *g_p++ = 0x0F; *g_p++ = cc; E32((uint32_t)(target - ((uintptr_t)g_p + 4))); } /* cc: 0x84 je, 0x85 jne, 0x8e jle ... */
static void ECALL(uintptr_t target) { *g_p++ = 0xE8; E32((uint32_t)(target - ((uintptr_t)g_p + 4))); }
static void ECOPY(uintptr_t src, size_t n) { memcpy(g_p, (void*)src, n); g_p += n; }
static void stub_end(void) { g_stub_used = (size_t)(g_p - g_stub_mem); }
/* redirect addr (n bytes, n>=5) to the stub being built at g_p */
static uint8_t* g_stub_start;
#define STUB_BEGIN() (g_stub_start = g_p)
static void hook_site(uintptr_t addr, size_t n, const void* expect) {
    uint8_t b[32]; memset(b, 0x90, sizeof b); b[0] = 0xE9; int32_t rel = (int32_t)((uintptr_t)g_stub_start - (addr + 5)); memcpy(b + 1, &rel, 4);
    if (!patch_bytes(addr, b, n, expect)) LOG("site patch @%08x failed", (unsigned)addr);
    g_stub_start = NULL;
}
/* emit "push eax; mov eax,[reg+prev]; cmp eax,[reg+cur]; pop eax" — ZF=1 if the timer's integer part did not change */
static void E_timer_unchanged(uint8_t reg_modrm_base, int32_t prev_off, int32_t cur_off) {
    E(0x50);                                            /* push eax */
    E(0x8B, 0x80 | reg_modrm_base); E32(prev_off);      /* mov eax,[reg+prev] */
    E(0x3B, 0x80 | reg_modrm_base); E32(cur_off);       /* cmp eax,[reg+cur]  */
    E(0x58);                                            /* pop eax */
}
/* emit "cmp dword [g_major],0" — ZF=1 on sub-ticks that are not frame boundaries */
static void E_not_major(void) { E(0x83, 0x3D); E32((uint32_t)(uintptr_t)&g_major); E(0x00); }
enum { R_EAX = 0, R_ECX = 1, R_EDX = 2, R_EBX = 3, R_EBP = 5, R_ESI = 6, R_EDI = 7 };

#include "th11_sites.h"

/* ------------------------------------------------------------------ enemy render interpolation
 * Enemies (ECL) stay on stock 60 Hz logic. To make them move smoothly we place their sprites, on every
 * tick, at the position interpolated between the last two frame positions (same lag as sub-stepped objects).
 */
#define G_ENEMY_MANAGER   (*(uint8_t**)0x4a8d7c)
#define G_ANM_MANAGER     (*(uint8_t**)0x4c3268)
typedef float* (*GetVmFn)(uint8_t* mgr, int id);
static float* anm_get_vm(uint8_t* mgr, int id) {
    float* r; uint8_t* m = mgr;
    __asm__ volatile ("push %2\n\t" "call *%3\n\t" : "=a"(r), "+d"(m) : "r"(id), "r"(0x4561e0) : "ecx", "memory", "cc");
    return r;
}
struct EnemyTrack { uint8_t* enemy; float last[3]; float prev[3]; unsigned seen; };
#define TRACK_N 2048
static struct EnemyTrack g_tracks[TRACK_N];
static unsigned g_major_count;
static struct EnemyTrack* track_find(uint8_t* e) {
    unsigned h = ((uintptr_t)e >> 4) & (TRACK_N - 1);
    struct EnemyTrack* stale = NULL;
    for (unsigned i = 0; i < 64; i++) {
        struct EnemyTrack* t = &g_tracks[(h + i) & (TRACK_N - 1)];
        if (t->enemy == e) return t;
        if (!stale && (t->enemy == NULL || t->seen + 2 < g_major_count)) stale = t;   /* free or not seen for 2 frames */
    }
    if (stale) { stale->enemy = NULL; }
    return stale;
}
static void enemy_interp(double phase) {
    if (!cfg.substep || !cfg.enemy_interp) return;
    uint8_t* em = G_ENEMY_MANAGER; uint8_t* am = G_ANM_MANAGER;
    if (!em || !am) return;
    int capture = g_major && !g_skip_update;
    if (capture) g_major_count++;
    float alpha = (float)(phase + g_dt); if (alpha > 1.0f) alpha = 1.0f;   /* fraction of the frame's motion to show */
    for (uint32_t* node = *(uint32_t**)(em + 0x68); node; node = (uint32_t*)node[1]) {
        uint8_t* e = (uint8_t*)node[0];
        if (!e) continue;
        uint32_t flags = *(uint32_t*)(e + 0x25bc);
        if (flags & 0x400000) continue; /* background-relative sprites keep their original path */
        float* P = (float*)(e + 0x1070);
        struct EnemyTrack* t = track_find(e);
        if (!t) continue;
        if (capture) {
            if (t->enemy == e && t->seen == g_major_count - 1) { memcpy(t->prev, t->last, 12); }
            else { memcpy(t->prev, P, 12); }
            memcpy(t->last, P, 12); t->enemy = e; t->seen = g_major_count;
        } else if (t->enemy != e) { memcpy(t->prev, P, 12); memcpy(t->last, P, 12); t->enemy = e; t->seen = g_major_count; }
        float d[3] = { t->last[0] - t->prev[0], t->last[1] - t->prev[1], t->last[2] - t->prev[2] };
        if (fabsf(d[0]) > 48.0f || fabsf(d[1]) > 48.0f) d[0] = d[1] = d[2] = 0;   /* teleport */
        float R[3] = { t->last[0] - d[0] * (1.0f - alpha), t->last[1] - d[1] * (1.0f - alpha), t->last[2] - d[2] * (1.0f - alpha) };
        int* ids = (int*)(e + 0x111c);
        for (int i = 0; i < 8; i++) {
            if (!ids[i]) continue;
            uint8_t* vm = (uint8_t*)anm_get_vm(am, ids[i]);
            if (!vm) continue;
            *(float*)(vm + 0x3e8) = R[0] + 224.0f;
            *(float*)(vm + 0x3ec) = R[1] + 16.0f;
            *(float*)(vm + 0x3f0) = R[2];
            if (*(int*)(vm + 0x18) == 0) {
                for (uint32_t* c = *(uint32_t**)(vm + 0x14); c; c = (uint32_t*)c[1]) {
                    uint8_t* child = (uint8_t*)c[0];
                    memcpy(child + 0x3e8, vm + 0x3e8, 12);
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ sub-tick input
 * The game polls the keyboard/joystick once per frame (Supervisor node, priority 1) into the raw input state at
 * 0x4c92a8 (0x130 bytes: cur, prev, repeat, pressed, released, 32 hold counters, held mask); the replay node
 * (priority 0xb) copies it into the game input word 0x4c93c0 and records it. Between frame ticks we poll again
 * with the game's own routine (so key/joystick mapping is unchanged) and feed only the movement and focus bits to
 * the game input word, which the (sub-stepped) player reads. Menus, shots, bombs and the game's replay record
 * keep the frame-sampled input. The per-tick bits are stored in memory per stage and written to the replay as an
 * extra USER chunk, and applied on playback.
 */
#define G_INPUT_RAW       ((uint8_t*)0x4c92a8)
#define G_INPUT_RAW_SIZE  0x130
#define G_GAME_INPUT      (*(uint32_t*)0x4c93c0)
#define G_OPTION_FLAGS    (*(uint32_t*)0x4c3480)
#define G_AUTOFOCUS_CTR   (*(int*)0x4c93bc)
#define IN_FOCUS 0x08
#define IN_MOVE  0xf0

/* joystick: winmm's joyGetPosEx can be slow; between frames return the last polled state */
typedef MMRESULT (WINAPI *JoyGetPosExFn)(UINT, LPJOYINFOEX);
static JoyGetPosExFn orig_joyGetPosEx;
static JOYINFOEX g_joy_cache; static MMRESULT g_joy_cache_res; static int g_joy_cache_valid, g_joy_use_cache;
static MMRESULT WINAPI hook_joyGetPosEx(UINT id, LPJOYINFOEX ji) {
    if (!ji) return orig_joyGetPosEx(id, ji);
    DWORD n = ji->dwSize < sizeof g_joy_cache ? ji->dwSize : (DWORD)sizeof g_joy_cache;
    if (g_joy_use_cache && id == 0 && g_joy_cache_valid) { memcpy(ji, &g_joy_cache, n); return g_joy_cache_res; }
    MMRESULT r = orig_joyGetPosEx(id, ji);
    if (id == 0) { memcpy(&g_joy_cache, ji, n); g_joy_cache_res = r; g_joy_cache_valid = 1; }
    return r;
}
/* Run TH11's input poll without disturbing the per-frame raw input state. */
static uint32_t poll_input_raw(void) {
    uint8_t save[G_INPUT_RAW_SIZE]; memcpy(save, G_INPUT_RAW, sizeof save);
    g_joy_use_cache = 1;
    uint32_t v;
    __asm__ volatile ("call *%1" : "=a"(v) : "r"(0x4576b0) : "ecx", "edx", "memory", "cc");
    g_joy_use_cache = 0;
    v = G_INPUT_CUR;
    memcpy(G_INPUT_RAW, save, sizeof save);
    return v;
}
/* movement + focus bits of a polled value, merged into the frame's game input word */
static uint32_t merge_subtick_bits(uint32_t frame_val, uint32_t polled, int live) {
    uint32_t v = (frame_val & ~(uint32_t)(IN_MOVE | IN_FOCUS)) | (polled & IN_MOVE);
    uint32_t focus = polled & IN_FOCUS;
    if (live && (G_OPTION_FLAGS & 0x200) && G_AUTOFOCUS_CTR >= 8) focus = IN_FOCUS;   /* "hold shot to focus" option: synthesized by the replay node */
    return v | focus;
}
static inline uint8_t  bits_encode(uint32_t v) { return (uint8_t)((v >> 3) & 0x1f); }
static inline uint32_t bits_decode(uint8_t b)  { return ((uint32_t)b & 0x1f) << 3; }

struct TickBuf { uint8_t* d; uint32_t n, cap; };
static struct TickBuf g_rec[8];    /* per stage: bits of every tick since the stage's first frame (this session) */
static struct TickBuf g_play[8];   /* per stage: the same, loaded from the replay being played */
static int      g_frame_active;    /* the replay node ran on the current frame's boundary tick */
static int      g_stream_stage = -1;
static uint32_t g_stream_tick;     /* index of the current tick in the stage stream */
static unsigned g_stat_subtick_polls, g_stat_subtick_applied;
static void tickbuf_push(struct TickBuf* b, uint8_t v) {
    if (b->n == b->cap) { uint32_t nc = b->cap ? b->cap * 2 : 65536; uint8_t* nd = (uint8_t*)realloc(b->d, nc); if (!nd) return; b->d = nd; b->cap = nc; }
    b->d[b->n++] = v;
}
/* called on the frame boundary tick just before the replay record/playback node runs its first frame of a stage */
static void replay_stage_start(uint8_t* rm) {
    int stage = *(int*)(rm + 0x1d4); int playing = *(int*)(rm + 0x10) == 1;
    schedule_reset_here();
    g_stream_stage = (stage >= 0 && stage < 8) ? stage : -1;
    g_stream_tick = 0;
    if (g_stream_stage >= 0 && !playing) g_rec[g_stream_stage].n = 0;
    LOG("stage %d first frame (%s): sub-step sequence restarted%s", stage, playing ? "playback" : "recording",
        (playing && g_stream_stage >= 0 && g_play[g_stream_stage].n) ? ", per-tick input available" : "");
}
static int subtick_active(uint8_t* rm) { return cfg.subtick_input && cfg.substep && g_logic_rate != 60 && rm && g_frame_active && g_stream_stage >= 0; }
/* start of a non-boundary tick: feed the player fresh (or recorded) movement/focus bits */
static void subtick_input_begin(void) {
    uint8_t* rm = G_REPLAY_MANAGER;
    if (!subtick_active(rm)) return;
    if (*(int*)(rm + 0x10) == 1) {
        struct TickBuf* b = &g_play[g_stream_stage];
        if (g_stream_tick < b->n) { G_GAME_INPUT = merge_subtick_bits(G_GAME_INPUT, bits_decode(b->d[g_stream_tick]), 0); g_stat_subtick_applied++; }
    } else {
        G_GAME_INPUT = merge_subtick_bits(G_GAME_INPUT, poll_input_raw(), 1); g_stat_subtick_polls++;
    }
}
/* end of every tick of an active frame: record the bits the player saw, advance the stream */
static void subtick_input_end(void) {
    uint8_t* rm = G_REPLAY_MANAGER;
    if (!subtick_active(rm)) return;
    if (*(int*)(rm + 0x10) != 1) tickbuf_push(&g_rec[g_stream_stage], bits_encode(G_GAME_INPUT));
    g_stream_tick++;
}

/* ------------------------------------------------------------------ update runner replacement */
typedef int (__thiscall *NodeFn)(void* arg);
struct ListNode { struct UpdateFunc* entry; struct ListNode* next; struct ListNode* prev; };
struct UpdateFunc { int priority; uint32_t flags; NodeFn func; void* on_reg; NodeFn on_cleanup; struct ListNode node; void* arg; };
_Static_assert(__builtin_offsetof(struct UpdateFunc, arg) == 0x20, "UpdateFunc layout");
typedef void (__fastcall *RemoveNodeFn)(struct UpdateFunc* uf, uint8_t* runner);
static RemoveNodeFn game_remove_node = (RemoveNodeFn)0x457080;

#define CRIT ((LPCRITICAL_SECTION)0x4c3a90)
#define CRIT_COUNT (*(volatile uint8_t*)0x4c3bb0)
static inline void crit_enter(void) { if (G_MISC_FLAGS & 0x8000) { EnterCriticalSection(CRIT); CRIT_COUNT++; } }
static inline void crit_leave(void) { if (G_MISC_FLAGS & 0x8000) { LeaveCriticalSection(CRIT); CRIT_COUNT--; } }

static struct UpdateFunc* g_stop_node; /* node that returned "stop" on the last frame tick */
static unsigned g_stat_sub_calls, g_stat_frame_calls, g_stat_long, g_stat_vlong;

int __cdecl __attribute__((used)) hfr_runner(uint8_t* runner) {
    int count = 0;
    if (g_skip_update && runner == G_UPDATE_RUNNER) { enemy_interp(g_phase); return 1; }
    int is_update = runner == G_UPDATE_RUNNER;
    if (is_update) {
        if (g_major) { g_stop_node = NULL; g_frame_active = 0; }
        else subtick_input_begin();
    }
    crit_enter();
    struct ListNode* n = *(struct ListNode**)(runner + 0x18);
restart:
    while (n) {
        struct UpdateFunc* uf = n->entry;
        n = n->next;
        if (!uf->func) continue;
        if (!(uf->flags & 2)) { count++; continue; }
    call_again:
        if (*(int*)(runner + 0x48) != 0) {
            if (uf->on_cleanup) uf->on_cleanup(uf->arg);
            count++; continue;
        }
        int mode = node_mode((uint32_t)uf->func);
        if (mode == MODE_FRAME && !g_major) {
            if (uf == g_stop_node) { count = 1; goto done; } /* the list was cut here on the last frame tick */
            /* GameManager (0x420840) returns "stop" while paused (flags 0x10/0x20/0x40); a pause raised by a
               sub-stepped node mid-frame must cut the list immediately, not only at the next frame tick */
            if ((uint32_t)uf->func == 0x420840) { uint8_t* gm = *(uint8_t**)0x4a8e88; if (gm && (*(uint32_t*)(gm + 0x60) & 0x70)) { count = 1; goto done; } }
            count++; continue;
        }
        crit_leave();
        uint32_t fn = (uint32_t)uf->func;
        int replay_node = is_update && g_major && (fn == 0x436d20 || fn == 0x436d30);   /* replay record / playback nodes */
        int frame_before = 0;
        if (replay_node) {
            uint8_t* rm = G_REPLAY_MANAGER;
            if (rm) { frame_before = *(int*)(rm + 0x1cc); if (frame_before == 0) replay_stage_start(rm); }
        }
        set_factor(mode == MODE_SUB ? g_dt : 1.0f);
        if (mode == MODE_SUB) g_stat_sub_calls++; else g_stat_frame_calls++;
        /* Edge-triggered actions (notably Marisa B formation switching) belong
           to the frame boundary, even while movement/focus are sampled faster. */
        uint32_t saved_pressed = 0, saved_released = 0, saved_bomb = 0;
        int player_minor = fn == 0x431c50 && !g_major;
        if (player_minor) {
            saved_pressed = *(uint32_t*)0x4c93cc;
            saved_released = *(uint32_t*)0x4c93d0;
            saved_bomb = G_GAME_INPUT & 2;
            G_GAME_INPUT &= ~2u;
            *(uint32_t*)0x4c93cc = *(uint32_t*)0x4c93d0 = 0;
        }
        int r = uf->func(uf->arg);
        if (player_minor) {
            *(uint32_t*)0x4c93cc = saved_pressed;
            *(uint32_t*)0x4c93d0 = saved_released;
            G_GAME_INPUT |= saved_bomb;
        }
        if (fn == 0x431c50) { uint8_t* pl = *(uint8_t**)0x4a8eb4; if (pl) { g_ptf_prev = g_ptf_cur; g_ptf_cur = *(float*)(pl + 0x94c); } }
        if (replay_node) { uint8_t* rm = G_REPLAY_MANAGER; if (rm && *(int*)(rm + 0x1cc) != frame_before) g_frame_active = 1; }
        crit_enter();
        switch (r) {
        case 0: game_remove_node(uf, runner); count++; break;
        case 2: if (uf->flags & 2) goto call_again; count++; break;
        case 3: if (g_major) g_stop_node = uf; count = 1; goto done;
        case 4: case 8: count = 0; goto done;
        case 5: count = -1; goto done;
        case 6: n = *(struct ListNode**)(runner + 0x18); count = 0; goto restart;
        case 7: if (uf->on_cleanup) uf->on_cleanup(uf->arg); count++; break;
        default: count++; break;
        }
    }
done:
    crit_leave();
    set_factor(1.0f);
    if (is_update) { subtick_input_end(); enemy_interp(g_phase); }
    return count;
}
__asm__(
    ".intel_syntax noprefix\n.globl _hfr_runner_entry\n_hfr_runner_entry:\n"
    "  push ebx\n  call _hfr_runner\n  add esp, 4\n  ret\n"
    ".att_syntax\n"
);
extern void hfr_runner_entry(void);

/* ------------------------------------------------------------------ frame limiter */
static LARGE_INTEGER g_qpf;
static double now_s(void) { LARGE_INTEGER t; QueryPerformanceCounter(&t); return (double)t.QuadPart / (double)g_qpf.QuadPart; }
static double g_next = 0;
static double g_stat_last = 0; static unsigned g_stat_ticks = 0;

static int g_vsync_effective = 1;   /* vsync appears to pace us: no sleeping in the limiter */
static double g_rate_win_start = 0; static unsigned g_rate_win_ticks = 0;
static unsigned g_stat_catchup; static long long g_stat_ticks_run_last; static long long g_ticks_run;

#define G_FRAME_FLAG34   (*(uint32_t*)0x4c37cc)
#define G_FRAME_FLAG38   (*(uint32_t*)0x4c37d0)
static void call_with_esi(uintptr_t fn, uintptr_t esi) {
    uintptr_t s = esi;
    __asm__ volatile ("call *%1" : "+S"(s) : "r"(fn) : "eax", "ecx", "edx", "memory", "cc");
}
/* an update pass without drawing/presenting (used to catch up after a missed vblank) */
static int update_only_tick(void) {
    G_FRAME_FLAG34 = 0x4c359c;
    G_FRAME_FLAG38 = 1;
    int r = hfr_runner(G_UPDATE_RUNNER);
    if (r == 0)  { call_with_esi(0x459430, 0x4c3a70); return 1; }
    if (r == -1) { call_with_esi(0x459430, 0x4c3a70); return 2; }
    return 0;
}

static void limiter_stats(double now) {
    g_stat_ticks++;
    { static double last = 0; double period = 1.0 / (double)g_refresh; if (last > 0) { double gap = now - last; if (gap > 1.5 * period) g_stat_long++; if (gap > 3 * period) g_stat_vlong++; } last = now; }
    g_rate_win_ticks++;
    if (g_rate_win_start == 0) g_rate_win_start = now;
    else if (now - g_rate_win_start >= 1.0) {
        double rate = g_rate_win_ticks / (now - g_rate_win_start);
        if (cfg.vsync && g_vsync_effective && rate > g_refresh * 1.08) { g_vsync_effective = 0; LOG("vsync does not seem to pace presentation (%.1f/s) — using software limiter", rate); }
        g_rate_win_start = now; g_rate_win_ticks = 0;
    }
    if (now - g_stat_last >= 5.0) {
        if (g_stat_last > 0)
            LOG("stats: %.2f presents/s (target %d), extra ticks %u, skipped ticks %u, sub calls %u, frame calls %u, logical %.3f, long gaps %u/%u, ticks/s %.2f, subtick polls %u applied %u",
                g_stat_ticks / (now - g_stat_last), g_refresh, g_stat_catchup, g_stat_skipped, g_stat_sub_calls, g_stat_frame_calls, g_logical, g_stat_long, g_stat_vlong,
                (double)(g_ticks_run - g_stat_ticks_run_last) / (now - g_stat_last), g_stat_subtick_polls, g_stat_subtick_applied);
        g_stat_last = now; g_stat_ticks = 0; g_stat_sub_calls = g_stat_frame_calls = g_stat_long = g_stat_vlong = g_stat_catchup = g_stat_skipped = 0; g_stat_ticks_run_last = g_ticks_run;
        g_stat_subtick_polls = g_stat_subtick_applied = 0;
        if (cfg.debug) {
            uint8_t* pl=*(uint8_t**)0x4a8eb4; uint8_t* rm=G_REPLAY_MANAGER;
            if (pl && rm) LOG("state: stage=%d replay_frame=%d replay_mode=%d character=%d player_state=%d timer=%.5f pos=(%.5f,%.5f) input=%08x",
                *(int*)(rm+0x1d4),*(int*)(rm+0x1cc),*(int*)(rm+0x10),
                *(int*)0x4a5710*3+*(int*)0x4a5714,*(int*)(pl+0x928),
                *(float*)(pl+0x94c),*(float*)(pl+0x87c),*(float*)(pl+0x880),(unsigned)G_GAME_INPUT);
        }
    }
}

/* ------------------------------------------------------------------ replay awareness */
/* A replay's rate is retained across device resets; no chunk means stock 60 Hz. */
static void replay_check(void) {
    uint8_t* rm = G_REPLAY_MANAGER;
    int playing = rm && *(int*)(rm + 0x10) == 1;
    if (playing != g_replay_playing) {
        g_replay_playing = playing;
        int want = playing ? (g_replay_rate ? g_replay_rate : 60) : g_refresh;
        if (cfg.fps > 0 && !playing) want = cfg.fps;
        LOG("replay playback %s -> logic rate %d", playing ? "started" : "ended", want);
        set_logic_rate(want);
    }
}


/* ------------------------------------------------------------------ replay file chunk (recording rate) */
#define HFR_CHUNK_TYPE 0x48   /* 'H' : our USER chunk type */
static int replay_path(char* out, size_t n, const char* name) {
    char dir[MAX_PATH]; GetModuleFileNameA(NULL, dir, MAX_PATH); char* p = strrchr(dir, '\\'); if (p) *p = 0;
    size_t a=strlen(dir),b=strlen(name);
    if (a+8+b+1>n) { LOG("Replay path is too long");return 0; }
    memcpy(out,dir,a);memcpy(out+a,"\\replay\\",8);memcpy(out+a+8,name,b+1);return 1;
}
#define HFR_INPUT_CHUNK_TYPE 0x49   /* 'I' : per-tick input chunk: "HFRI", u16 version, u16 rate, u8 nstages, pad[3],
                                       then per stage: u8 stage, pad[3], u32 nticks, u32 npairs, npairs x {u8 bits, u8 run} */
static void replay_append_chunk(const char* name) {
    if (!cfg.substep || g_logic_rate == 60) return;
    char path[MAX_PATH]; if (!replay_path(path, sizeof path, name)) return;
    HANDLE h = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) { LOG("replay chunk: cannot open %s", path); return; }
    uint8_t buf[64]; memset(buf, 0, sizeof buf);
    int len = snprintf((char*)buf + 12, sizeof buf - 12, "th11_hfr rate=%d", g_logic_rate) + 1;
    uint32_t size = (12 + len + 3) & ~3u;
    memcpy(buf, "USER", 4); memcpy(buf + 4, &size, 4); buf[8] = HFR_CHUNK_TYPE;
    DWORD w = 0; WriteFile(h, buf, size, &w, NULL);
    LOG("replay chunk written to %s (rate %d)", name, g_logic_rate);
    /* per-tick input chunk for the stages present in the replay */
    uint8_t* rm = G_REPLAY_MANAGER;
    if (cfg.subtick_input && rm) {
        uint32_t cap = 24, used = 24; uint8_t* out = (uint8_t*)malloc(cap); int nst = 0; uint32_t total_ticks = 0;
        if (out) {
            for (int s = 0; s < 8; s++) {
                if (!*(uint32_t*)(rm + 0x1c + s * 4) || g_rec[s].n == 0) continue;
                uint32_t need = used + 12 + 2 * g_rec[s].n;
                if (need > cap) { uint8_t* no = (uint8_t*)realloc(out, need); if (!no) break; out = no; cap = need; }
                uint8_t* hdr = out + used; used += 12;
                uint32_t npairs = 0;
                for (uint32_t i = 0; i < g_rec[s].n;) { uint8_t v = g_rec[s].d[i]; uint32_t j = i; while (j < g_rec[s].n && g_rec[s].d[j] == v && j - i < 255) j++; out[used++] = v; out[used++] = (uint8_t)(j - i); npairs++; i = j; }
                memset(hdr, 0, 12); hdr[0] = (uint8_t)s; memcpy(hdr + 4, &g_rec[s].n, 4); memcpy(hdr + 8, &npairs, 4);
                nst++; total_ticks += g_rec[s].n;
            }
            uint32_t size2 = (used + 3) & ~3u;
            if (size2 > cap) { uint8_t* no = (uint8_t*)realloc(out, size2); if (no) { out = no; cap = size2; } else size2 = used & ~3u; }
            memset(out, 0, 24); memcpy(out, "USER", 4); memcpy(out + 4, &size2, 4); out[8] = HFR_INPUT_CHUNK_TYPE;
            memcpy(out + 12, "HFRI", 4); uint16_t ver = 1, rate = (uint16_t)g_logic_rate; memcpy(out + 16, &ver, 2); memcpy(out + 18, &rate, 2); out[20] = (uint8_t)nst;
            if (used < size2) memset(out + used, 0, size2 - used);
            if (nst) { WriteFile(h, out, size2, &w, NULL); LOG("replay input chunk written: %d stage(s), %u ticks, %u bytes", nst, total_ticks, size2); }
            free(out);
        }
    }
    CloseHandle(h);
}
static void replay_parse_input_chunk(const uint8_t* p, uint32_t size) {
    for (int s = 0; s < 8; s++) g_play[s].n = 0;
    if (size < 24 || memcmp(p + 12, "HFRI", 4) != 0) return;
    uint16_t ver, rate; memcpy(&ver, p + 16, 2); memcpy(&rate, p + 18, 2); int nst = p[20];
    if (ver != 1 || rate < 60 || rate > 1000 || nst > 8) {
        LOG("replay input chunk: unsupported header"); return;
    }
    /* Validate every RLE stage before allocating or accepting any stream. */
    uint32_t check = 24, seen = 0;
    for (int k = 0; k < nst; ++k) {
        if (check > size || size - check < 12) return;
        unsigned s = p[check]; uint32_t nt, np;
        memcpy(&nt,p+check+4,4); memcpy(&np,p+check+8,4); check+=12;
        if (s>=8 || (seen & (1u<<s)) || nt>3600000 || np>(size-check)/2) return;
        seen |= 1u<<s;
        uint32_t sum=0;
        for (uint32_t i=0;i<np;++i) {
            unsigned bits=p[check+2*i], run=p[check+2*i+1];
            if (bits>31 || !run || sum>nt || run>nt-sum) return;
            sum+=run;
        }
        if (sum!=nt) return;
        check+=2*np;
    }
    uint32_t off = 24;
    for (int k = 0; k < nst; k++) {
        if (off + 12 > size) break;
        int s = p[off]; uint32_t nticks, npairs; memcpy(&nticks, p + off + 4, 4); memcpy(&npairs, p + off + 8, 4); off += 12;
        if (off + 2 * npairs > size) break;
        if (s >= 0 && s < 8) {
            struct TickBuf* b = &g_play[s]; b->n = 0;
            for (uint32_t i = 0; i < npairs; i++) { uint8_t v = p[off + 2 * i], run = p[off + 2 * i + 1]; for (unsigned r = 0; r < run; r++) tickbuf_push(b, v); }
            LOG("replay input chunk: stage %d, %u ticks (%u recorded), rate %u", s, b->n, nticks, rate);
        }
        off += 2 * npairs;
    }
}
static int replay_read_chunk(const char* name) {
    for (int s = 0; s < 8; s++) g_play[s].n = 0;
    char path[MAX_PATH]; if (!replay_path(path, sizeof path, name)) return 0;
    HANDLE h = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD sz = GetFileSize(h, NULL); int rate = 0;
    if (sz > 0 && sz < 64 * 1024 * 1024) {
        uint8_t* d = (uint8_t*)malloc(sz + 1); DWORD rd = 0;
        if (d && ReadFile(h, d, sz, &rd, NULL) && rd == sz) {
            d[sz] = 0;
            DWORD start = 0;
            if (sz >= 0x24 && memcmp(d, "t11r", 4) == 0) { uint32_t uo; memcpy(&uo, d + 0xc, 4); if (uo >= 0x24 && uo < sz) start = uo; }   /* header +0xc: user data offset */
            for (DWORD i = start; i + 16 <= sz; i++) {
                if (memcmp(d + i, "USER", 4) != 0) continue;
                uint32_t csize; memcpy(&csize, d + i + 4, 4);
                if (csize < 12 || csize > sz - i) continue;
                if (d[i + 8] == HFR_CHUNK_TYPE) {
                    char t[64]; size_t len=csize-12; if(len>=sizeof t)len=sizeof t-1;
                    memcpy(t,d+i+12,len);t[len]=0; const char* k = strstr(t, "rate=");
                    if (k) rate = atoi(k + 5);
                } else if (d[i + 8] == HFR_INPUT_CHUNK_TYPE) {
                    replay_parse_input_chunk(d + i, csize);
                }
                i += csize - 1;
            }
        }
        free(d);
    }
    CloseHandle(h);
    return rate >= 60 && rate <= 1000 ? rate : 0;
}
typedef void (__fastcall *ReplaySaveFn)(char* filename, char* name, int p3);
typedef int (__stdcall *ReplayLoadFn)(void* mgr, char* filename);
static ReplaySaveFn orig_replay_save = (ReplaySaveFn)0x436420;
static ReplayLoadFn orig_replay_load = (ReplayLoadFn)0x436b60;
static void __fastcall hfr_replay_save(char* filename, char* name, int p3) {
    orig_replay_save(filename, name, p3);
    replay_append_chunk(filename);
}
static int __stdcall hfr_replay_load(void* mgr, char* filename) {
    int r = orig_replay_load(mgr, filename);
    g_replay_rate = replay_read_chunk(filename);
    LOG("replay %s loaded for playback: recorded rate %d", filename, g_replay_rate);
    return r;
}

/* ------------------------------------------------------------------ frame hook */

static int __stdcall hfr_frame(void* ctx) {
    double now = now_s();
    replay_check();
    if (g_t0 == 0) { g_t0 = now; g_ticks_run = 0; }
    /* how many ticks we should have run by now (long-term schedule) minus how many we did */
    double expected = (now - g_t0) * (double)g_logic_rate;
    long long deficit = (long long)floor(expected) - g_ticks_run;
    if (deficit > 60 || deficit < -60) {              /* stall / clock jump: re-anchor instead of catching up */
        g_t0 = now - (double)g_ticks_run / (double)g_logic_rate; deficit = 0;
    }
    if (!(cfg.vsync && g_vsync_effective)) {
        /* Pace presentation independently: stock replays still present at HFR. */
        if (g_next == 0 || fabs(now - g_next) > 0.25) g_next = now;
        double due = g_next;
        while (now < due) {
            double rem = due - now;
            if (rem > 0.0025) Sleep(1); else if (rem > 0.0008) Sleep(0); else YieldProcessor();
            now = now_s();
        }
        expected = (now - g_t0) * (double)g_logic_rate;
        deficit = (long long)floor(expected) - g_ticks_run;
        g_next = due + 1.0 / (double)g_refresh;
    }
    limiter_stats(now);
    int n = ticks_for_slot();
    if (deficit > 6) { n += 1; g_stat_catchup++; }         /* presentation is slower than the display rate: catch up (6 = hysteresis for the DWM present queue) */
    else if (deficit < -6 && n > 0) { n -= 1; g_stat_skipped++; } /* presentation is faster: hold a tick back */
    for (int i = 0; i + 1 < n; i++) { advance_tick(); int r = update_only_tick(); if (r) return r; }
    if (n >= 1) { advance_tick(); g_skip_update = 0; } else g_skip_update = 1;
    g_ticks_run += n;
    int r = orig_frame_vsync(ctx);
    g_skip_update = 0;
    return r;
}

/* ------------------------------------------------------------------ Direct3D hooks */
typedef HRESULT (__stdcall *CreateDeviceFn)(IDirect3D9*, UINT, D3DDEVTYPE, HWND, DWORD, D3DPRESENT_PARAMETERS*, IDirect3DDevice9**);
typedef HRESULT (__stdcall *ResetFn)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
typedef IDirect3D9* (__stdcall *Direct3DCreate9Fn)(UINT);
static CreateDeviceFn orig_CreateDevice; static ResetFn orig_Reset; static Direct3DCreate9Fn orig_Direct3DCreate9;

static int detect_refresh(IDirect3DDevice9* dev) {
    int hz = 0;
    if (dev) { D3DDISPLAYMODE m; if (SUCCEEDED(dev->lpVtbl->GetDisplayMode(dev, 0, &m)) && m.RefreshRate > 0) hz = m.RefreshRate; }
    if (hz <= 1) { DEVMODEA dm; memset(&dm, 0, sizeof dm); dm.dmSize = sizeof dm;
        if (EnumDisplaySettingsA(NULL, ENUM_CURRENT_SETTINGS, &dm) && dm.dmDisplayFrequency > 1) hz = dm.dmDisplayFrequency; }
    if (hz <= 1) hz = 60;
    return hz;
}
/* Direct3D 9Ex: the device is created through IDirect3D9Ex::CreateDeviceEx so that the present queue depth can be
   limited (SetMaximumFrameLatency), which removes up to two frames of display latency. 9Ex has no managed pool,
   so managed resources are turned into default-pool dynamic ones (device CreateTexture/CreateVertexBuffer/
   CreateIndexBuffer and the D3DX texture loaders the game imports). */
static int g_using_ex = 0;
typedef HRESULT (WINAPI *Direct3DCreate9ExFn)(UINT, IDirect3D9Ex**);
static void patch_vtable(void** vt, int idx, void* hook, void** orig) {
    if (*orig) return;
    *orig = vt[idx]; DWORD old; VirtualProtect(&vt[idx], 4, PAGE_EXECUTE_READWRITE, &old); vt[idx] = hook; VirtualProtect(&vt[idx], 4, old, &old);
}
typedef HRESULT (__stdcall *CreateTextureFn)(IDirect3DDevice9*, UINT, UINT, UINT, DWORD, D3DFORMAT, D3DPOOL, IDirect3DTexture9**, HANDLE*);
typedef HRESULT (__stdcall *CreateVertexBufferFn)(IDirect3DDevice9*, UINT, DWORD, DWORD, D3DPOOL, IDirect3DVertexBuffer9**, HANDLE*);
typedef HRESULT (__stdcall *CreateIndexBufferFn)(IDirect3DDevice9*, UINT, DWORD, D3DFORMAT, D3DPOOL, IDirect3DIndexBuffer9**, HANDLE*);
static CreateTextureFn orig_CreateTexture; static CreateVertexBufferFn orig_CreateVertexBuffer; static CreateIndexBufferFn orig_CreateIndexBuffer;
static unsigned g_stat_managed_conv;
static inline void unmanage(D3DPOOL* pool, DWORD* usage) { if (*pool == D3DPOOL_MANAGED) { *pool = D3DPOOL_DEFAULT; *usage |= D3DUSAGE_DYNAMIC; g_stat_managed_conv++; } }
static HRESULT __stdcall hook_CreateTexture(IDirect3DDevice9* dev, UINT w, UINT h, UINT levels, DWORD usage, D3DFORMAT fmt, D3DPOOL pool, IDirect3DTexture9** out, HANDLE* sh) {
    unmanage(&pool, &usage); return orig_CreateTexture(dev, w, h, levels, usage, fmt, pool, out, sh);
}
static HRESULT __stdcall hook_CreateVertexBuffer(IDirect3DDevice9* dev, UINT len, DWORD usage, DWORD fvf, D3DPOOL pool, IDirect3DVertexBuffer9** out, HANDLE* sh) {
    unmanage(&pool, &usage); return orig_CreateVertexBuffer(dev, len, usage, fvf, pool, out, sh);
}
static HRESULT __stdcall hook_CreateIndexBuffer(IDirect3DDevice9* dev, UINT len, DWORD usage, D3DFORMAT fmt, D3DPOOL pool, IDirect3DIndexBuffer9** out, HANDLE* sh) {
    unmanage(&pool, &usage); return orig_CreateIndexBuffer(dev, len, usage, fmt, pool, out, sh);
}
typedef HRESULT (__stdcall *D3DXCreateTextureFn)(IDirect3DDevice9*, UINT, UINT, UINT, DWORD, D3DFORMAT, D3DPOOL, IDirect3DTexture9**);
typedef HRESULT (__stdcall *D3DXCreateTextureFromFileInMemoryExFn)(IDirect3DDevice9*, LPCVOID, UINT, UINT, UINT, UINT, DWORD, D3DFORMAT, D3DPOOL, DWORD, DWORD, D3DCOLOR, void*, PALETTEENTRY*, IDirect3DTexture9**);
static D3DXCreateTextureFn orig_D3DXCreateTexture; static D3DXCreateTextureFromFileInMemoryExFn orig_D3DXCreateTextureFromFileInMemoryEx;
static HRESULT __stdcall hook_D3DXCreateTexture(IDirect3DDevice9* dev, UINT w, UINT h, UINT mip, DWORD usage, D3DFORMAT fmt, D3DPOOL pool, IDirect3DTexture9** out) {
    if (g_using_ex) unmanage(&pool, &usage);
    return orig_D3DXCreateTexture(dev, w, h, mip, usage, fmt, pool, out);
}
static HRESULT __stdcall hook_D3DXCreateTextureFromFileInMemoryEx(IDirect3DDevice9* dev, LPCVOID src, UINT srcsize, UINT w, UINT h, UINT mip, DWORD usage, D3DFORMAT fmt, D3DPOOL pool, DWORD filter, DWORD mipfilter, D3DCOLOR key, void* info, PALETTEENTRY* pal, IDirect3DTexture9** out) {
    if (g_using_ex) unmanage(&pool, &usage);
    return orig_D3DXCreateTextureFromFileInMemoryEx(dev, src, srcsize, w, h, mip, usage, fmt, pool, filter, mipfilter, key, info, pal, out);
}
static int hook_iat(const char* dll, const char* func, void* hook, void** orig);

static void apply_pp(D3DPRESENT_PARAMETERS* pp) {
    pp->PresentationInterval = cfg.vsync ? D3DPRESENT_INTERVAL_ONE : D3DPRESENT_INTERVAL_IMMEDIATE;
    if (!pp->Windowed) {
        int hz = cfg.fullscreen_refresh ? cfg.fullscreen_refresh : (cfg.fps > 0 ? cfg.fps : detect_refresh(NULL));
        pp->FullScreen_RefreshRateInHz = hz > 0 ? hz : D3DPRESENT_RATE_DEFAULT;
    }
    if (g_using_ex) {
        if (pp->Windowed && cfg.flipex) { pp->SwapEffect = D3DSWAPEFFECT_FLIPEX; if (pp->BackBufferCount < 2) pp->BackBufferCount = 2; }
        else if (pp->SwapEffect == D3DSWAPEFFECT_FLIPEX) { pp->SwapEffect = D3DSWAPEFFECT_DISCARD; }
    }
    LOG("present params: windowed=%d %ux%u refresh=%u interval=0x%x backbuffers=%u swap=%d", pp->Windowed, pp->BackBufferWidth,
        pp->BackBufferHeight, pp->FullScreen_RefreshRateInHz, pp->PresentationInterval, pp->BackBufferCount, pp->SwapEffect);
}
static void fill_mode_ex(D3DPRESENT_PARAMETERS* pp, D3DDISPLAYMODEEX* m) {
    memset(m, 0, sizeof *m); m->Size = sizeof *m; m->Width = pp->BackBufferWidth; m->Height = pp->BackBufferHeight;
    m->RefreshRate = pp->FullScreen_RefreshRateInHz; m->Format = pp->BackBufferFormat; m->ScanLineOrdering = D3DSCANLINEORDERING_PROGRESSIVE;
}
static void after_device(IDirect3DDevice9* dev) {
    int hz = detect_refresh(dev);
    LOG("display refresh detected: %d Hz", hz);
    recompute_rate(cfg.fps > 0 ? cfg.fps : hz);
    g_next = 0;
    if (g_using_ex && cfg.max_frame_latency > 0) {
        IDirect3DDevice9Ex* ex = (IDirect3DDevice9Ex*)dev;
        HRESULT hr = ex->lpVtbl->SetMaximumFrameLatency(ex, (UINT)cfg.max_frame_latency);
        UINT got = 0; ex->lpVtbl->GetMaximumFrameLatency(ex, &got);
        LOG("SetMaximumFrameLatency(%d) -> 0x%08lx (now %u)", cfg.max_frame_latency, (long)hr, got);
    }
}
static HRESULT __stdcall hook_Reset(IDirect3DDevice9* dev, D3DPRESENT_PARAMETERS* pp) {
    apply_pp(pp);
    HRESULT hr;
    if (g_using_ex) {
        IDirect3DDevice9Ex* ex = (IDirect3DDevice9Ex*)dev; D3DDISPLAYMODEEX m; fill_mode_ex(pp, &m);
        hr = ex->lpVtbl->ResetEx(ex, pp, pp->Windowed ? NULL : &m);
        LOG("ResetEx -> 0x%08lx", (long)hr);
    } else {
        hr = orig_Reset(dev, pp);
        LOG("Reset -> 0x%08lx", (long)hr);
    }
    if (SUCCEEDED(hr)) after_device(dev);
    return hr;
}
static HRESULT __stdcall hook_CreateDevice(IDirect3D9* d3d, UINT adapter, D3DDEVTYPE type, HWND hwnd, DWORD flags, D3DPRESENT_PARAMETERS* pp, IDirect3DDevice9** out) {
    apply_pp(pp);
    HRESULT hr;
    if (g_using_ex) {
        IDirect3D9Ex* ex = (IDirect3D9Ex*)d3d; D3DDISPLAYMODEEX m; fill_mode_ex(pp, &m);
        hr = ex->lpVtbl->CreateDeviceEx(ex, adapter, type, hwnd, flags, pp, pp->Windowed ? NULL : &m, (IDirect3DDevice9Ex**)out);
        LOG("CreateDeviceEx -> 0x%08lx", (long)hr);
        if (FAILED(hr)) { hr = orig_CreateDevice(d3d, adapter, type, hwnd, flags, pp, out); LOG("fallback CreateDevice on the 9Ex object -> 0x%08lx", (long)hr); }
        if (SUCCEEDED(hr) && out && *out) {
            static const GUID iid_dev9ex = { 0xb18b10ce, 0x2649, 0x405a, { 0x87, 0x0f, 0x95, 0xf7, 0x77, 0xd4, 0x31, 0x3a } };
            void* q = NULL;
            if (SUCCEEDED((*out)->lpVtbl->QueryInterface(*out, &iid_dev9ex, &q)) && q) { ((IUnknown*)q)->lpVtbl->Release((IUnknown*)q); }
            else { LOG("device does not expose IDirect3DDevice9Ex; 9Ex features disabled"); g_using_ex = 0; }
            if (hwnd) SetWindowPos(hwnd, 0, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);   /* 9Ex resets the window style */
        }
    } else {
        hr = orig_CreateDevice(d3d, adapter, type, hwnd, flags, pp, out);
        LOG("CreateDevice -> 0x%08lx", (long)hr);
    }
    if (SUCCEEDED(hr) && out && *out) {
        IDirect3DDevice9* dev = *out;
        void** vt = *(void***)dev;
        patch_vtable(vt, 16, (void*)hook_Reset, (void**)&orig_Reset);
        if (g_using_ex) {
            patch_vtable(vt, 23, (void*)hook_CreateTexture, (void**)&orig_CreateTexture);
            patch_vtable(vt, 26, (void*)hook_CreateVertexBuffer, (void**)&orig_CreateVertexBuffer);
            patch_vtable(vt, 27, (void*)hook_CreateIndexBuffer, (void**)&orig_CreateIndexBuffer);
        }
        after_device(dev);
    }
    return hr;
}
static IDirect3D9* __stdcall hook_Direct3DCreate9(UINT sdk) {
    IDirect3D9* d3d = NULL;
    if (cfg.d3d9ex) {
        /* use the d3d9.dll the game resolved its import from (a wrapper in the game folder stays in the chain) */
        HMODULE m = GetModuleHandleA("d3d9.dll");
        Direct3DCreate9ExFn createEx = m ? (Direct3DCreate9ExFn)GetProcAddress(m, "Direct3DCreate9Ex") : NULL;
        if (createEx) {
            IDirect3D9Ex* ex = NULL; HRESULT hr = createEx(sdk, &ex);
            if (SUCCEEDED(hr) && ex) { d3d = (IDirect3D9*)ex; g_using_ex = 1; LOG("Direct3DCreate9Ex ok (%s)", "hooked"); }
            else LOG("Direct3DCreate9Ex failed (0x%08lx), using Direct3DCreate9", (long)hr);
        } else LOG("Direct3DCreate9Ex not available, using Direct3DCreate9");
    }
    if (!d3d) d3d = orig_Direct3DCreate9(sdk);
    if (d3d) {
        void** vt = *(void***)d3d;
        patch_vtable(vt, 16, (void*)hook_CreateDevice, (void**)&orig_CreateDevice);
        LOG("Direct3DCreate9 hooked (9Ex=%d)", g_using_ex);
    }
    return d3d;
}
static int hook_iat(const char* dll, const char* func, void* hook, void** orig) {
    uint8_t* base = (uint8_t*)GetModuleHandleA(NULL);
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base; IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    IMAGE_DATA_DIRECTORY dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    IMAGE_IMPORT_DESCRIPTOR* imp = (IMAGE_IMPORT_DESCRIPTOR*)(base + dir.VirtualAddress);
    for (; imp->Name; imp++) {
        if (_stricmp((char*)(base + imp->Name), dll) != 0) continue;
        IMAGE_THUNK_DATA* thunk = (IMAGE_THUNK_DATA*)(base + imp->FirstThunk);
        IMAGE_THUNK_DATA* oth = (IMAGE_THUNK_DATA*)(base + imp->OriginalFirstThunk);
        for (; oth->u1.AddressOfData; thunk++, oth++) {
            if (oth->u1.Ordinal & IMAGE_ORDINAL_FLAG) continue;
            IMAGE_IMPORT_BY_NAME* ibn = (IMAGE_IMPORT_BY_NAME*)(base + oth->u1.AddressOfData);
            if (strcmp((char*)ibn->Name, func) != 0) continue;
            DWORD old; VirtualProtect(&thunk->u1.Function, 4, PAGE_READWRITE, &old);
            *orig = (void*)thunk->u1.Function; thunk->u1.Function = (DWORD)hook;
            VirtualProtect(&thunk->u1.Function, 4, old, &old);
            return 1;
        }
    }
    return 0;
}

/* ------------------------------------------------------------------ init */
static void read_config(void) {
    char ini[MAX_PATH]; GetModuleFileNameA(NULL, ini, MAX_PATH);
    char* p = strrchr(ini, '\\'); if (p) strcpy(p + 1, "th11_hfr.ini"); else strcpy(ini, "th11_hfr.ini");
    cfg.fps = GetPrivateProfileIntA("hfr", "fps", 0, ini);
    cfg.vsync = GetPrivateProfileIntA("hfr", "vsync", 1, ini);
    cfg.substep = GetPrivateProfileIntA("hfr", "substep", 1, ini);
    cfg.log = GetPrivateProfileIntA("hfr", "log", 1, ini);
    cfg.fullscreen_refresh = GetPrivateProfileIntA("hfr", "fullscreen_refresh", 0, ini);
    cfg.enemy_interp = GetPrivateProfileIntA("hfr", "enemy_interp", 1, ini);
    cfg.debug = GetPrivateProfileIntA("hfr", "debug", 0, ini);
    cfg.subtick_input = GetPrivateProfileIntA("hfr", "subtick_input", 1, ini);
    cfg.d3d9ex = GetPrivateProfileIntA("hfr", "d3d9ex", 1, ini);
    cfg.max_frame_latency = GetPrivateProfileIntA("hfr", "max_frame_latency", 1, ini);
    cfg.flipex = GetPrivateProfileIntA("hfr", "flipex", 0, ini);
    for (size_t i = 0; i < sizeof g_classes / sizeof g_classes[0]; i++) {
        char key[64]; snprintf(key, sizeof key, "sub_%s", g_classes[i].name);
        g_sub_enabled[i] = GetPrivateProfileIntA("systems", key, g_classes[i].mode == MODE_SUB, ini);
    }
}

#include "th11_install.h"

/* ------------------------------------------------------------------ dinput8.dll proxy mode */
typedef HRESULT (WINAPI *DirectInput8CreateFn)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
static DirectInput8CreateFn real_DirectInput8Create;
__declspec(dllexport) HRESULT WINAPI DirectInput8Create(HINSTANCE hinst, DWORD ver, REFIID riid, LPVOID* out, LPUNKNOWN outer) {
    if (!real_DirectInput8Create) {
        char path[MAX_PATH]; GetSystemDirectoryA(path, MAX_PATH); strcat(path, "\\dinput8.dll");
        HMODULE m = LoadLibraryA(path);
        if (m) real_DirectInput8Create = (DirectInput8CreateFn)GetProcAddress(m, "DirectInput8Create");
    }
    if (!real_DirectInput8Create) return E_FAIL;
    return real_DirectInput8Create(hinst, ver, riid, out, outer);
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID res) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        /* only one instance may patch (the DLL can be loaded as th11_hfr.dll and as dinput8.dll) */
        char mutex_name[80]; snprintf(mutex_name, sizeof mutex_name, "th11_hfr_%lu", GetCurrentProcessId());
        HANDLE mtx = CreateMutexA(NULL, FALSE, mutex_name);
        if (mtx && GetLastError() == ERROR_ALREADY_EXISTS) return TRUE;
        read_config();
        if (cfg.log) { char path[MAX_PATH]; GetModuleFileNameA(NULL, path, MAX_PATH); char* p = strrchr(path, '\\'); if (p) strcpy(p + 1, "th11_hfr.log"); g_log = fopen(path, "w"); }
        LOG("th11_hfr v0.1.0-test loading; fps=%d vsync=%d substep=%d subtick_input=%d d3d9ex=%d max_frame_latency=%d flipex=%d enemy_interp=%d",
            cfg.fps, cfg.vsync, cfg.substep, cfg.subtick_input, cfg.d3d9ex, cfg.max_frame_latency, cfg.flipex, cfg.enemy_interp);
        install();
    }
    return TRUE;
}
