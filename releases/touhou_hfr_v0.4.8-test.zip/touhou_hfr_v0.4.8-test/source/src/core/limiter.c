/* ------------------------------------------------------------------ frame limiter */
static LARGE_INTEGER g_qpf;
static double now_s(void) { LARGE_INTEGER t; QueryPerformanceCounter(&t); return (double)t.QuadPart / (double)g_qpf.QuadPart; }
static double g_next = 0;
static double g_stat_last = 0; static unsigned g_stat_ticks = 0;

static int g_vsync_effective = 1;   /* vsync appears to pace us: no sleeping in the limiter */
static double g_rate_win_start = 0; static unsigned g_rate_win_ticks = 0;
static unsigned g_stat_catchup; static long long g_stat_ticks_run_last; static long long g_ticks_run;

#define G_FRAME_FLAG34   (*(uint32_t*)g_game->addr.frame_context_ptr)
#define G_FRAME_FLAG38   (*(uint32_t*)g_game->addr.frame_flag)
static void call_with_esi(uintptr_t fn, uintptr_t esi) {
    uintptr_t s = esi;
    __asm__ volatile ("call *%1" : "+S"(s) : "r"(fn) : "eax", "ecx", "edx", "memory", "cc");
}
/* an update pass without drawing/presenting (used to catch up after a missed vblank) */
static int update_only_tick(void) {
    G_FRAME_FLAG34 = g_game->addr.frame_context_value;
    G_FRAME_FLAG38 = 1;
    int r = hfr_runner(G_UPDATE_RUNNER);
    if (r == 0)  { call_with_esi(g_game->addr.cleanup_fn, g_game->addr.cleanup_this); return 1; }
    if (r == -1) { call_with_esi(g_game->addr.cleanup_fn, g_game->addr.cleanup_this); return 2; }
    return 0;
}

/* How many frames were presented with no logic tick behind them. This is the number that
   answers "is the high frame rate real, or is it showing the same frame twice?" -- a repeated
   frame is exactly a present with nothing simulated since the last one. At the intended
   settings it is zero: the tick rate is the present rate, so every frame has its own tick.
   It is legitimately non-zero when the tick rate is deliberately set below the display rate
   (fps=60 on a 144 Hz screen asks for stock logic shown at 144 Hz), and when the game is
   paused or between stages and the simulation is not running at all. */
static unsigned g_stat_repeat_frames;
static uint64_t g_stat_ticks_run_prev;

/* The tick counter restarts when a replay begins or ends, so the difference across a window
   that contains one of those goes negative -- and a log that reports -2936 ticks/s is a log
   nobody can use to judge whether the frame rate is real. Report nothing rather than nonsense. */
static double tick_rate_since(double now) {
    double dt = now - g_stat_last;
    if (dt <= 0 || g_ticks_run < g_stat_ticks_run_last) return 0.0;
    return (double)(g_ticks_run - g_stat_ticks_run_last) / dt;
}

static void limiter_stats(double now) {
    g_stat_ticks++;
    if (g_ticks_run == g_stat_ticks_run_prev) g_stat_repeat_frames++;
    g_stat_ticks_run_prev = g_ticks_run;
    { static double last = 0; static unsigned hitches_logged; double period = 1.0 / (double)g_refresh;
      if (last > 0) { double gap = now - last; if (gap > 1.5 * period) g_stat_long++;
          if (gap > 3 * period) { g_stat_vlong++;
              /* A hitch: say how long, and what this frame did, so a stutter report carries its own evidence. */
              if (gap > 0.04 && hitches_logged < 40) { hitches_logged++;
                  static unsigned last_tex_done, last_tex_redone;
                  LOG("hitch: %.1f ms between presents (target %.1f); this frame: %u draw calls, %u forced batch flushes, %u sprite VM draws, textures upscaled +%u redone +%u",
                      gap * 1000.0, period * 1000.0, g_frame_draws, g_frame_flushes, g_frame_vms, g_stat_tex_done - last_tex_done, g_stat_tex_redone - last_tex_redone);
                  last_tex_done = g_stat_tex_done; last_tex_redone = g_stat_tex_redone; } } }
      last = now; g_frame_draws = g_frame_flushes = g_frame_vms = 0; }
    g_rate_win_ticks++;
    if (g_rate_win_start == 0) g_rate_win_start = now;
    else if (now - g_rate_win_start >= 1.0) {
        double rate = g_rate_win_ticks / (now - g_rate_win_start);
        if (cfg.vsync && g_vsync_effective && rate > g_refresh * 1.08) { g_vsync_effective = 0; LOG("vsync does not seem to pace presentation (%.1f/s) — using software limiter", rate); }
        g_rate_win_start = now; g_rate_win_ticks = 0;
    }
    if (now - g_stat_last >= 5.0) {
        if (g_stat_last > 0)
            LOG("stats: %.2f presents/s (target %d), extra ticks %u, skipped ticks %u, sub calls %u, frame calls %u, logical %.3f, long gaps %u/%u, ticks/s %.2f, subtick polls %u applied %u, repeated frames %u/%u",
                g_stat_ticks / (now - g_stat_last), g_refresh, g_stat_catchup, g_stat_skipped, g_stat_sub_calls, g_stat_frame_calls, g_logical, g_stat_long, g_stat_vlong,
                tick_rate_since(now), g_stat_subtick_polls, g_stat_subtick_applied,
                g_stat_repeat_frames, g_stat_ticks);
        if (g_stat_last > 0 && (g_gap_inside_long || g_gap_outside_long))
            LOG("frame time: inside the game's frame function max %.1f ms (%u over 8 ms), outside it max %.1f ms (%u over 8 ms); longest spans: before first draw %.1f, drawing %.1f, in Present %.1f, after Present %.1f",
                g_gap_inside_max * 1000.0, g_gap_inside_long, g_gap_outside_max * 1000.0, g_gap_outside_long,
                g_span_max[0] * 1000.0, g_span_max[1] * 1000.0, g_span_max[2] * 1000.0, g_span_max[3] * 1000.0);
        g_gap_inside_max = g_gap_outside_max = 0; g_gap_inside_long = g_gap_outside_long = 0; memset(g_span_max, 0, sizeof g_span_max);
        { static unsigned last_done, last_redone; if (g_stat_tex_done != last_done || g_stat_tex_redone != last_redone) { LOG("textures: %u upscaled, %u redone after a rewrite, %u MB", g_stat_tex_done, g_stat_tex_redone, (unsigned)(g_tex_bytes >> 20)); last_done = g_stat_tex_done; last_redone = g_stat_tex_redone; } }
        g_stat_last = now; g_stat_ticks = 0; g_stat_sub_calls = g_stat_frame_calls = g_stat_long = g_stat_vlong = g_stat_catchup = g_stat_skipped = 0; g_stat_ticks_run_last = g_ticks_run;
        g_stat_subtick_polls = g_stat_subtick_applied = 0; g_stat_repeat_frames = 0;
        if (cfg.debug) {
            uint8_t* rm=G_REPLAY_MANAGER;
            if (rm) LOG("state: stage=%d replay_frame=%d replay_mode=%d input=%08x",
                *(int*)(rm+g_game->layout.replay_stage),*(int*)(rm+g_game->layout.replay_frame),*(int*)(rm+0x10),(unsigned)G_GAME_INPUT);
        }
    }
}
