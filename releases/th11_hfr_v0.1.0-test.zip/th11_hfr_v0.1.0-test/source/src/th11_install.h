static int verify_exe(void) {
    uint8_t* base=(uint8_t*)GetModuleHandleA(NULL);
    if ((uintptr_t)base != 0x400000) return 0;
    IMAGE_DOS_HEADER* dos=(IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    IMAGE_NT_HEADERS* nt=(IMAGE_NT_HEADERS*)(base+dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->FileHeader.Machine != IMAGE_FILE_MACHINE_I386 ||
        nt->OptionalHeader.SizeOfImage < 0xcc000) return 0;
    int ok=1;
    for (size_t i=0; i<sizeof th11_signatures/sizeof *th11_signatures; ++i) {
        const struct Th11Signature* s=&th11_signatures[i];
        if (s->addr+s->size > (uintptr_t)base+nt->OptionalHeader.SizeOfImage ||
            memcmp((void*)s->addr,s->bytes,s->size)) {
            LOG("TH11 preflight mismatch @%08x (%u bytes)",(unsigned)s->addr,(unsigned)s->size);
            ok=0;
        }
    }
    if (ok) LOG("TH11 v1.00a preflight: all %u signatures verified",(unsigned)(sizeof th11_signatures/sizeof *th11_signatures));
    return ok;
}
static int install(void) {
    if (!verify_exe()) { LOG("Unsupported/modified executable: no HFR hooks applied"); return 0; }
    g_p=stub_begin();
    if (!g_stub_mem) { LOG("Cannot allocate hook stubs; no hooks applied"); return 0; }
    QueryPerformanceFrequency(&g_qpf); timeBeginPeriod(1);
    /* Install the address-dependent prerequisites before switching the frame loop. */
    install_speed_patches(); install_site_patches();
    const uintptr_t saves[]={0x42d2ae,0x42e21b,0x42ef4b,0x4403c5};
    for (int i=0; i<4; ++i) site_call(saves[i],hfr_replay_save);
    site_call(0x435a0d,hfr_replay_load);
    uint8_t latency[7]; memcpy(latency,site_expected(0x446799,7),7); latency[6]=0x7f;
    patch_bytes(0x446799,latency,7,site_expected(0x446799,7));
    LOG("latency sleep disabled @00446799");
    patch_jmp(0x456cb0,hfr_runner_entry,site_expected(0x456cb0,5));
    site_call(0x44587e,hfr_frame); site_call(0x44589b,hfr_frame); site_call(0x4458a7,hfr_frame);
    if (!hook_iat("d3d9.dll","Direct3DCreate9",hook_Direct3DCreate9,(void**)&orig_Direct3DCreate9)) LOG("Direct3D IAT hook failed");
    if (cfg.d3d9ex) {
        int a=hook_iat("d3dx9_37.dll","D3DXCreateTexture",hook_D3DXCreateTexture,(void**)&orig_D3DXCreateTexture);
        int b=hook_iat("d3dx9_37.dll","D3DXCreateTextureFromFileInMemoryEx",hook_D3DXCreateTextureFromFileInMemoryEx,(void**)&orig_D3DXCreateTextureFromFileInMemoryEx);
        if (!a || !b) { cfg.d3d9ex=0; LOG("D3DX hooks unavailable (%d,%d): using D3D9",a,b); }
    }
    if (cfg.subtick_input) hook_iat("winmm.dll","joyGetPosEx",hook_joyGetPosEx,(void**)&orig_joyGetPosEx);
    recompute_rate(cfg.fps > 0 ? cfg.fps : detect_refresh(NULL));
    return 1;
}
