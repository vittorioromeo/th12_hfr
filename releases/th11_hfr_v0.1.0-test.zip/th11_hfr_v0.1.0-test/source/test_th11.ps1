param(
    [Parameter(Mandatory=$true)][string[]]$GameExe,
    [string]$Compiler='C:\msys64\mingw32\bin\gcc.exe',
    [string]$Python='python'
)
$ErrorActionPreference='Stop'
$compilerPath=(Get-Command $Compiler -ErrorAction Stop).Source
$pythonPath=(Get-Command $Python -ErrorAction Stop).Source
$fixtures=@($GameExe | ForEach-Object {(Resolve-Path -LiteralPath $_).Path})
$savedPath=$env:PATH
$env:PATH="$(Split-Path -Parent $compilerPath);$savedPath"
Push-Location $PSScriptRoot
try {
    New-Item -ItemType Directory -Force 'build/tests' | Out-Null
    & $pythonPath tools/verify_th11.py @fixtures
    if($LASTEXITCODE){throw 'Executable verification failed'}
    # The padding keeps PE sections contiguous while reserving the game address.
    & $compilerPath -std=gnu11 -O2 -static-libgcc tools/test_th11.c -o build/tests/test_th11.exe -ld3d9 -lwinmm '-Wl,--image-base,0x300000,--disable-dynamicbase,--section-start,.fixture=0x400000,--section-start,.pad=0x32a000'
    if($LASTEXITCODE){throw 'Native harness build failed'}
    for($i=0;$i -lt $fixtures.Count;++$i) {
        $prefix="build/tests/fixture$i"
        & './build/tests/test_th11.exe' $fixtures[$i] $prefix
        if($LASTEXITCODE){throw 'Native regression failed'}
        & $pythonPath tools/test_th11_stubs.py $prefix
        if($LASTEXITCODE){throw 'Machine-code regression failed'}
    }
} finally { Pop-Location; $env:PATH=$savedPath }
