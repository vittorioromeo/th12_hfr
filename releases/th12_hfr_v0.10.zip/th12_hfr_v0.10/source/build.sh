#!/bin/sh
set -e
cd /home/claude/hfr
i686-w64-mingw32-gcc -O2 -Wall -Wno-unused-function -shared -static-libgcc -o th12_hfr.dll hfr.c -ld3d9 -lwinmm -Wl,--kill-at
i686-w64-mingw32-gcc -O2 -s -mwindows -static-libgcc -o th12_hfr.exe launcher.c
ls -la th12_hfr.dll th12_hfr.exe
