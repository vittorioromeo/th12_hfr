#!/bin/sh
# package.sh <version>  -> /mnt/user-data/outputs/th12_hfr_v<version>.zip
set -e
V=$1; [ -n "$V" ] || { echo "usage: package.sh <version>"; exit 1; }
cd /home/claude/hfr && ./build.sh >/dev/null
P=/tmp/pkg_$V; rm -rf $P; mkdir -p $P/th12_hfr_v$V/source
cp th12_hfr.dll $P/th12_hfr_v$V/dinput8.dll
cp th12_hfr.dll th12_hfr.exe th12_hfr.ini README.md $P/th12_hfr_v$V/
cp hfr.c launcher.c build.sh package.sh $P/th12_hfr_v$V/source/
(cd $P && rm -f th12_hfr_v$V.zip && zip -qr th12_hfr_v$V.zip th12_hfr_v$V)
mkdir -p /home/claude/hfr_versions/v$V && cp -r $P/th12_hfr_v$V/. /home/claude/hfr_versions/v$V/
cp $P/th12_hfr_v$V.zip /home/claude/hfr_versions/ && cp $P/th12_hfr_v$V.zip /mnt/user-data/outputs/
ls -la /mnt/user-data/outputs/th12_hfr_v$V.zip
