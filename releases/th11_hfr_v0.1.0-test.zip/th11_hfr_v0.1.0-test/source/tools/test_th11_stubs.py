"""Emulate the actual x86 stubs emitted by test_th11.c. Requires unicorn.
Usage: python tools/test_th11_stubs.py build/native11
The .game/.stubs/.json files are local test artifacts, never release contents.
"""
import json
import struct
import sys
from pathlib import Path
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn.x86_const import *

prefix=sys.argv[1]
meta=json.loads(Path(prefix+'.json').read_text())
u=Uc(UC_ARCH_X86,UC_MODE_32)
mapped=set()
def map_region(address,size):
    for page in range(address&~4095,(address+size+4095)&~4095,4096):
        if page not in mapped:
            u.mem_map(page,4096);mapped.add(page)
def wi(address,value):u.mem_write(address,struct.pack('<I',value&0xffffffff))
def ri(address):return struct.unpack('<I',u.mem_read(address,4))[0]
def wf(address,value):u.mem_write(address,struct.pack('<f',value))
def rf(address):return struct.unpack('<f',u.mem_read(address,4))[0]
for name,base in (('game',0x400000),('stubs',meta['stub_base'])):
    data=Path(prefix+'.'+name).read_bytes();map_region(base,len(data));u.mem_write(base,data)
for name,address in meta.items():
    if name!='stub_base':map_region(address,8)
ARENA=0x20000000;STACK=ARENA+0xf0000;BOOT=ARENA+0xe0000
map_region(ARENA,0x100000)
regs=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_EBP]
def reset(major=0):
    u.mem_write(ARENA,bytes(0x10000));u.reg_write(UC_X86_REG_ESP,STACK)
    for i,reg in enumerate(regs):u.reg_write(reg,ARENA+0x1000+i*0x100)
    u.reg_write(UC_X86_REG_EFLAGS,0x247)
    wi(meta['major'],major);wf(meta['factor'],0.25);wf(meta['logical'],1)
    wf(meta['residual'],0);wf(meta['residual']+4,0)
    u.mem_write(BOOT,b'\xdb\xe3');u.emu_start(BOOT,BOOT+2)
def fpush(value):
    wf(BOOT+64,value);u.mem_write(BOOT,b'\xd9\x05'+struct.pack('<I',BOOT+64))
    u.emu_start(BOOT,BOOT+6)
ends=set()
def on_code(uc,address,size,unused):
    if address in ends:uc.emu_stop()
u.hook_add(UC_HOOK_CODE,on_code)
def run(start,*stop):
    global ends
    ends=set(stop);u.emu_start(start,0,count=2000)
    pc=u.reg_read(UC_X86_REG_EIP)
    assert pc in ends,f'Unexpected endpoint {pc:x}, wanted {[hex(x) for x in ends]}'
    return pc

# Both branches of every ordinary gate, with stack/register/flag preservation
# checked on the skipped path. Execute only the displaced prefix on the other.
gates=[
 (0x408cbc,5,0x408cd8,UC_X86_REG_EBX,0x464),
 (0x402bc5,10,0x40311b,UC_X86_REG_EBX,-1),
 (0x403121,6,0x403127,UC_X86_REG_EBX,-1),
 (0x425de0,6,0x425df1,UC_X86_REG_EBP,0x14),
 (0x426097,9,0x4260f6,UC_X86_REG_EBP,0x28),
 (0x427580,9,0x4275ec,UC_X86_REG_ESI,0x14),
 (0x4312c6,7,0x4313e6,UC_X86_REG_ESI,0x944),
 (0x431ab6,6,0x431af7,UC_X86_REG_ESI,0x944),
 (0x43065f,6,0x430665,UC_X86_REG_EBP,-1),
 (0x43078f,6,0x4307ab,UC_X86_REG_EBP,-1),
 (0x430b48,6,0x430b4e,UC_X86_REG_EBP,-1),
 (0x430b4e,6,0x430d91,UC_X86_REG_EBP,-1),
]
for start,n,skip,reg,timer in gates:
    for changed in (0,1):
        reset(changed)
        if timer>=0:
            obj=u.reg_read(reg);wi(obj+timer,5);wi(obj+timer+4,5+changed)
        before=[u.reg_read(r) for r in regs];flags=u.reg_read(UC_X86_REG_EFLAGS)
        pc=run(start,start+n,skip)
        assert pc==(start+n if changed else skip)
        assert u.reg_read(UC_X86_REG_ESP)==STACK
        if not changed:
            assert before==[u.reg_read(r) for r in regs]
            assert flags==u.reg_read(UC_X86_REG_EFLAGS)
print('PASS: 24 guard paths, including preserved flags/registers/stack')

for start,n,reg,timer in ((0x408070,7,UC_X86_REG_ECX,0x5c),(0x452420,9,UC_X86_REG_ECX,0x5c),
                           (0x434e30,6,UC_X86_REG_EDX,0),(0x4352a0,6,UC_X86_REG_EDX,0)):
    for changed in (0,1):
        reset();obj=u.reg_read(reg);wi(obj+timer,5);wi(obj+timer+4,5+changed)
        wi(STACK,BOOT+128)
        pc=run(start,start+n,BOOT+128)
        assert pc==(start+n if changed else BOOT+128)
        if not changed:
            assert u.reg_read(UC_X86_REG_EAX)==0 and u.reg_read(UC_X86_REG_ESP)==STACK+4
print('PASS: mesh and shot callbacks return only when their integer timer is unchanged')

# State-5 items: preserve all five pending x87 pops and signed expiry branch.
for major,count,target in ((0,0,0x423ec3),(1,0,0x4235c6),(1,2,0x423ec3)):
    reset(major);obj=u.reg_read(UC_X86_REG_EDI);wi(obj+0x474,count)
    for i in range(5):fpush(i+1)
    pc=run(0x4235af,0x423ec3,0x4235c6)
    assert pc==target and ri(obj+0x474)==(count-major)&0xffffffff
    assert u.reg_read(UC_X86_REG_FPTAG)==0xffff
print('PASS: item countdown expires once, with a balanced x87 stack')

reset();wi(STACK+0x2c,640);wi(STACK+0x10,-320)
run(0x43066e,0x4306ce)
assert ri(STACK+0x2c)==1280 and ri(STACK+0x10)==(-640)&0xffffffff
assert u.reg_read(UC_X86_REG_ESP)==STACK
print('PASS: Reimu C speed bonus applies on minor ticks without spawning extra particles')

reset();obj=u.reg_read(UC_X86_REG_EBX)
for i,value in enumerate((10,20,30,4,-8,12)):wf(obj+i*4,value)
run(0x45959c,0x4595b7)
assert [rf(obj+i*4) for i in range(3)]==[11,18,33]
assert u.reg_read(UC_X86_REG_FPTAG)==0xffff
for start,stop,reg in ((0x4315a5,0x4315ac,UC_X86_REG_EDI),(0x434562,0x434569,UC_X86_REG_ESI)):
    reset();obj=u.reg_read(reg);wf(obj+0x18,4);wf(obj+0x14,3)
    run(start,stop)
    # Execute displaced value's following store to inspect the x87 result.
    run(stop,stop+3);assert rf(obj+0x14)==4
    assert u.reg_read(UC_X86_REG_ESP)==STACK-4
for start,reg in ((0x4315af,UC_X86_REG_EDI),(0x43456c,UC_X86_REG_ESI)):
    reset();obj=u.reg_read(reg);wf(obj+0xc,4);wf(obj+0x10,3)
    run(start,start+6)
    u.mem_write(BOOT,b'\xd9\x1d'+struct.pack('<I',BOOT+64));ends=set();u.emu_start(BOOT,BOOT+6)
    assert rf(BOOT+64)==4
print('PASS: Cartesian motion, acceleration and angular increments scale by the sub-step')

# Exercise the actual game's ftol as well as our remainder-carry stub.
for sse in (0,1):
    for value in (3.75,-3.75,0.25,-0.25):
        reset();wi(0x4c9ccc,sse)
        total=0
        for _ in range(4):
            fpush(value);run(0x430722,0x430727)
            result=u.reg_read(UC_X86_REG_EAX);total+=result if result<2**31 else result-2**32
            assert u.reg_read(UC_X86_REG_ESP)==STACK
            assert u.reg_read(UC_X86_REG_FPTAG)==0xffff
        assert total==int(value*4),(sse,value,total)
        reset();wf(meta['factor'],1);wf(meta['residual'],0.75);wi(0x4c9ccc,sse)
        fpush(value);run(0x430722,0x430727)
        assert u.reg_read(UC_X86_REG_EAX)==int(value)&0xffffffff
print('PASS: positive/negative fixed-point residuals, SSE/x87 ftol paths, and stock truncation')

# Constant timer offsets must not be scaled by dt; this call uses ret 4.
reset();obj=u.reg_read(UC_X86_REG_ESI);wi(obj+4,17);wf(obj+8,17.25)
wf(STACK,-14);run(0x4343fc,0x434401)
assert rf(obj+8)==3.25 and ri(obj+4)==3 and ri(obj)==17
assert u.reg_read(UC_X86_REG_ESP)==STACK+4
print('PASS: shot-cycle constant subtraction and callee stack cleanup')
